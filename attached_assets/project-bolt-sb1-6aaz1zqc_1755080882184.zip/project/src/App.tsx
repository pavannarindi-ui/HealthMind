import React, { useState } from 'react';
import { Heart } from 'lucide-react';
import LanguageSelection from './components/LanguageSelection';
import InputTypeSelection from './components/InputTypeSelection';
import TextInput from './components/TextInput';
import VoiceInput from './components/VoiceInput';
import ImageInput from './components/ImageInput';
import ProcessingLoader from './components/ProcessingLoader';
import ResultsDisplay from './components/ResultsDisplay';
import { DEFAULT_LANGUAGE } from './constants/languages';
import { MockHealthcareAI } from './utils/mockAI';
import { DiagnosisResult } from './types';

type AppStep = 
  | 'language-selection'
  | 'input-type-selection'
  | 'text-input'
  | 'voice-input'
  | 'image-input'
  | 'processing'
  | 'results';

function App() {
  const [currentStep, setCurrentStep] = useState<AppStep>('language-selection');
  const [selectedLanguage, setSelectedLanguage] = useState(DEFAULT_LANGUAGE);
  const [inputData, setInputData] = useState<{
    text?: string;
    images?: File[];
  }>({});
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosisResult | null>(null);

  // Step 1: Language Selection
  const handleLanguageSelect = (language: string) => {
    setSelectedLanguage(language);
    setCurrentStep('input-type-selection');
  };

  // Step 2: Input Type Selection
  const handleInputTypeSelect = (type: 'text' | 'voice' | 'image') => {
    switch (type) {
      case 'text':
        setCurrentStep('text-input');
        break;
      case 'voice':
        setCurrentStep('voice-input');
        break;
      case 'image':
        setCurrentStep('image-input');
        break;
    }
  };

  // Step 3-5: Input Handlers
  const handleTextSubmit = (text: string) => {
    setInputData({ text });
    setCurrentStep('processing');
  };

  const handleVoiceSubmit = (text: string) => {
    setInputData({ text });
    setCurrentStep('processing');
  };

  const handleImageSubmit = (description: string, images: File[]) => {
    setInputData({ text: description, images });
    setCurrentStep('processing');
  };

  // Step 6: Processing Complete
  const handleProcessingComplete = async () => {
    try {
      const result = await MockHealthcareAI.analyzeSymptoms(
        inputData.text || '',
        selectedLanguage,
        inputData.images
      );
      setDiagnosisResult(result);
      setCurrentStep('results');
    } catch (error) {
      console.error('Error during diagnosis:', error);
      // Handle error - could show error message or restart
      setCurrentStep('input-type-selection');
    }
  };

  // Navigation
  const handleBack = () => {
    switch (currentStep) {
      case 'input-type-selection':
        setCurrentStep('language-selection');
        break;
      case 'text-input':
      case 'voice-input':
      case 'image-input':
        setCurrentStep('input-type-selection');
        break;
      default:
        break;
    }
  };

  const handleRestart = () => {
    setCurrentStep('language-selection');
    setSelectedLanguage(DEFAULT_LANGUAGE);
    setInputData({});
    setDiagnosisResult(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center items-center py-4">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900">AI Healthcare Assistant</h1>
                <p className="text-sm text-gray-600">Multilingual Medical Support</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-8 px-4">
        {currentStep === 'language-selection' && (
          <LanguageSelection
            selectedLanguage={selectedLanguage}
            onLanguageSelect={handleLanguageSelect}
          />
        )}

        {currentStep === 'input-type-selection' && (
          <InputTypeSelection
            language={selectedLanguage}
            onInputTypeSelect={handleInputTypeSelect}
          />
        )}

        {currentStep === 'text-input' && (
          <TextInput
            language={selectedLanguage}
            onSubmit={handleTextSubmit}
            onBack={handleBack}
          />
        )}

        {currentStep === 'voice-input' && (
          <VoiceInput
            language={selectedLanguage}
            onSubmit={handleVoiceSubmit}
            onBack={handleBack}
          />
        )}

        {currentStep === 'image-input' && (
          <ImageInput
            language={selectedLanguage}
            onSubmit={handleImageSubmit}
            onBack={handleBack}
          />
        )}

        {currentStep === 'processing' && (
          <ProcessingLoader
            language={selectedLanguage}
            onComplete={handleProcessingComplete}
          />
        )}

        {currentStep === 'results' && diagnosisResult && (
          <ResultsDisplay
            language={selectedLanguage}
            result={diagnosisResult}
            onRestart={handleRestart}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-400 text-sm">
            © 2025 AI Healthcare Assistant. This tool is for educational purposes only and should not replace professional medical advice.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;