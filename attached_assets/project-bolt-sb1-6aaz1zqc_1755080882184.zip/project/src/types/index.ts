export interface Language {
  code: string;
  name: string;
  nativeName: string;
}

export interface HealthcareSession {
  id: string;
  language: string;
  symptoms: string[];
  images?: File[];
  voiceInput?: string;
  diagnosis?: string;
  recommendations?: string;
  medications?: string[];
}

export interface InputType {
  id: 'text' | 'voice' | 'image';
  label: string;
  icon: string;
}

export interface ProcessingStep {
  id: string;
  label: string;
  completed: boolean;
  current: boolean;
}

export interface DiagnosisResult {
  condition: string;
  confidence: number;
  symptoms: string[];
  recommendations: string[];
  medications: string[];
  severity: 'low' | 'medium' | 'high';
}