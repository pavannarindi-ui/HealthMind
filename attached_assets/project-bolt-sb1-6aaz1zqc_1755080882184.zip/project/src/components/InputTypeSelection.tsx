import React from 'react';
import { MessageSquare, Mic, Camera } from 'lucide-react';
import { getTranslation } from '../utils/translations';
import { InputType } from '../types';

interface InputTypeSelectionProps {
  language: string;
  onInputTypeSelect: (type: 'text' | 'voice' | 'image') => void;
}

const InputTypeSelection: React.FC<InputTypeSelectionProps> = ({
  language,
  onInputTypeSelect
}) => {
  const inputTypes: InputType[] = [
    {
      id: 'text',
      label: getTranslation(language, 'textInput'),
      icon: 'MessageSquare'
    },
    {
      id: 'voice',
      label: getTranslation(language, 'voiceInput'),
      icon: 'Mic'
    },
    {
      id: 'image',
      label: getTranslation(language, 'imageInput'),
      icon: 'Camera'
    }
  ];

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'MessageSquare':
        return MessageSquare;
      case 'Mic':
        return Mic;
      case 'Camera':
        return Camera;
      default:
        return MessageSquare;
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {getTranslation(language, 'selectInputType')}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {inputTypes.map((inputType) => {
          const IconComponent = getIcon(inputType.icon);
          return (
            <button
              key={inputType.id}
              onClick={() => onInputTypeSelect(inputType.id)}
              className="p-6 rounded-xl border-2 border-gray-200 hover:border-blue-500 hover:bg-blue-50 transition-all duration-200 text-center group"
            >
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 group-hover:bg-blue-100 rounded-full mb-4 transition-colors">
                <IconComponent className="w-8 h-8 text-gray-600 group-hover:text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 group-hover:text-blue-900">
                {inputType.label}
              </h3>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default InputTypeSelection;