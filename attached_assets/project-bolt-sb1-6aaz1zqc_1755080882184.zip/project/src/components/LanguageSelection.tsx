import React from 'react';
import { Globe } from 'lucide-react';
import { SUPPORTED_LANGUAGES } from '../constants/languages';
import { getTranslation } from '../utils/translations';
import { Language } from '../types';

interface LanguageSelectionProps {
  selectedLanguage: string;
  onLanguageSelect: (language: string) => void;
}

const LanguageSelection: React.FC<LanguageSelectionProps> = ({
  selectedLanguage,
  onLanguageSelect
}) => {
  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-4">
          <Globe className="w-8 h-8 text-blue-600" />
        </div>
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {getTranslation(selectedLanguage, 'selectLanguage')}
        </h2>
        <p className="text-gray-600">
          {getTranslation(selectedLanguage, 'languagePrompt')}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {SUPPORTED_LANGUAGES.map((language: Language) => (
          <button
            key={language.code}
            onClick={() => onLanguageSelect(language.code)}
            className={`p-4 rounded-xl border-2 transition-all duration-200 text-left hover:shadow-md ${
              selectedLanguage === language.code
                ? 'border-blue-500 bg-blue-50 shadow-md'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="font-semibold text-gray-900">{language.nativeName}</div>
            <div className="text-sm text-gray-600">{language.name}</div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default LanguageSelection;