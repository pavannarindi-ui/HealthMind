import React, { useState, useRef } from 'react';
import { Mic, MicOff, Play, Store as Stop } from 'lucide-react';
import { getTranslation } from '../utils/translations';
import { MockHealthcareAI } from '../utils/mockAI';

interface VoiceInputProps {
  language: string;
  onSubmit: (text: string) => void;
  onBack: () => void;
}

const VoiceInput: React.FC<VoiceInputProps> = ({ language, onSubmit, onBack }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [transcription, setTranscription] = useState('');
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        setAudioBlob(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Error starting recording:', error);
      alert('Unable to access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processAudio = async () => {
    if (!audioBlob) return;

    setIsProcessing(true);
    try {
      const text = await MockHealthcareAI.processVoiceInput(audioBlob, language);
      setTranscription(text);
    } catch (error) {
      console.error('Error processing audio:', error);
      alert('Error processing audio. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSubmit = () => {
    if (transcription) {
      onSubmit(transcription);
    }
  };

  const playAudio = () => {
    if (audioBlob) {
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      audio.play();
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {getTranslation(language, 'voiceInputLabel')}
        </h2>
      </div>

      <div className="space-y-6">
        {/* Recording Controls */}
        <div className="text-center">
          <button
            onClick={isRecording ? stopRecording : startRecording}
            className={`inline-flex items-center justify-center w-20 h-20 rounded-full transition-all duration-200 ${
              isRecording
                ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
                : 'bg-blue-500 hover:bg-blue-600 text-white'
            }`}
          >
            {isRecording ? <MicOff className="w-8 h-8" /> : <Mic className="w-8 h-8" />}
          </button>
          <p className="mt-4 text-gray-600">
            {isRecording
              ? getTranslation(language, 'recordingInProgress')
              : getTranslation(language, isRecording ? 'stopRecording' : 'startRecording')
            }
          </p>
        </div>

        {/* Audio Playback */}
        {audioBlob && !isRecording && (
          <div className="text-center">
            <button
              onClick={playAudio}
              className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              <Play className="w-4 h-4" />
              Play Recording
            </button>
          </div>
        )}

        {/* Process Audio */}
        {audioBlob && !transcription && !isProcessing && (
          <div className="text-center">
            <button
              onClick={processAudio}
              className="px-6 py-3 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors"
            >
              Process Audio
            </button>
          </div>
        )}

        {/* Processing Indicator */}
        {isProcessing && (
          <div className="text-center">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
            <p className="mt-2 text-gray-600">Processing audio...</p>
          </div>
        )}

        {/* Transcription */}
        {transcription && (
          <div className="p-4 bg-gray-50 rounded-xl">
            <h3 className="font-semibold text-gray-900 mb-2">Transcription:</h3>
            <p className="text-gray-700">{transcription}</p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-4">
          <button
            onClick={onBack}
            className="flex-1 py-3 px-6 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
          >
            {getTranslation(language, 'back')}
          </button>
          {transcription && (
            <button
              onClick={handleSubmit}
              className="flex-1 py-3 px-6 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
            >
              {getTranslation(language, 'continue')}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default VoiceInput;