import React, { useEffect } from 'react';
import { AlertTriangle, CheckCircle, Info, Download, RotateCcw, Volume2 } from 'lucide-react';
import { getTranslation } from '../utils/translations';
import { DiagnosisResult } from '../types';
import { ttsService } from '../utils/tts';

interface ResultsDisplayProps {
  language: string;
  result: DiagnosisResult;
  onRestart: () => void;
}

const ResultsDisplay: React.FC<ResultsDisplayProps> = ({ language, result, onRestart }) => {
  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'high':
        return <AlertTriangle className="w-6 h-6 text-red-600" />;
      case 'medium':
        return <Info className="w-6 h-6 text-yellow-600" />;
      case 'low':
        return <CheckCircle className="w-6 h-6 text-green-600" />;
      default:
        return <Info className="w-6 h-6 text-blue-600" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high':
        return 'bg-red-50 border-red-200 text-red-900';
      case 'medium':
        return 'bg-yellow-50 border-yellow-200 text-yellow-900';
      case 'low':
        return 'bg-green-50 border-green-200 text-green-900';
      default:
        return 'bg-blue-50 border-blue-200 text-blue-900';
    }
  };

  const speakResults = async () => {
    const textToSpeak = `
      ${getTranslation(language, 'diagnosisTitle')}: ${result.condition}.
      ${getTranslation(language, 'recommendationsTitle')}: ${result.recommendations.join('. ')}.
      ${getTranslation(language, 'medicationsTitle')}: ${result.medications.join(', ')}.
    `;
    
    try {
      await ttsService.speak(textToSpeak, language);
    } catch (error) {
      console.error('Error with text-to-speech:', error);
    }
  };

  const downloadSummary = () => {
    const summary = `
Healthcare Assessment Summary
============================

Condition: ${result.condition}
Confidence: ${(result.confidence * 100).toFixed(1)}%
Severity: ${getTranslation(language, `severityLevels.${result.severity}`)}

Symptoms Identified:
${result.symptoms.map(symptom => `• ${symptom}`).join('\n')}

Recommendations:
${result.recommendations.map(rec => `• ${rec}`).join('\n')}

Suggested Medications:
${result.medications.map(med => `• ${med}`).join('\n')}

Disclaimer: ${getTranslation(language, 'disclaimer')}

Generated on: ${new Date().toLocaleString()}
    `;

    const blob = new Blob([summary], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `healthcare-assessment-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Diagnosis Card */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            {getTranslation(language, 'diagnosisTitle')}
          </h2>
          <button
            onClick={speakResults}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Listen to results"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        <div className={`p-4 rounded-xl border-2 ${getSeverityColor(result.severity)} mb-6`}>
          <div className="flex items-center gap-3 mb-2">
            {getSeverityIcon(result.severity)}
            <h3 className="text-xl font-semibold">{result.condition}</h3>
          </div>
          <p className="text-sm opacity-75">
            Confidence: {(result.confidence * 100).toFixed(1)}% • 
            {getTranslation(language, `severityLevels.${result.severity}`)}
          </p>
        </div>

        {/* Symptoms */}
        <div className="mb-6">
          <h4 className="font-semibold text-gray-900 mb-3">Identified Symptoms:</h4>
          <div className="flex flex-wrap gap-2">
            {result.symptoms.map((symptom, index) => (
              <span
                key={index}
                className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-sm"
              >
                {symptom}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Recommendations Card */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">
          {getTranslation(language, 'recommendationsTitle')}
        </h3>
        <ul className="space-y-3">
          {result.recommendations.map((recommendation, index) => (
            <li key={index} className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5 flex-shrink-0" />
              <span className="text-gray-700">{recommendation}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* Medications Card */}
      <div className="bg-white rounded-2xl shadow-lg p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">
          {getTranslation(language, 'medicationsTitle')}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {result.medications.map((medication, index) => (
            <div
              key={index}
              className="p-3 bg-blue-50 border border-blue-200 rounded-lg"
            >
              <span className="font-medium text-blue-900">{medication}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Disclaimer */}
      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
          <p className="text-yellow-800 text-sm">
            {getTranslation(language, 'disclaimer')}
          </p>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={downloadSummary}
          className="flex-1 py-3 px-6 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors flex items-center justify-center gap-2"
        >
          <Download className="w-5 h-5" />
          {getTranslation(language, 'downloadSummary')}
        </button>
        <button
          onClick={onRestart}
          className="flex-1 py-3 px-6 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors flex items-center justify-center gap-2"
        >
          <RotateCcw className="w-5 h-5" />
          {getTranslation(language, 'restart')}
        </button>
      </div>
    </div>
  );
};

export default ResultsDisplay;