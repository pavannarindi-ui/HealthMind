import React from 'react';
import { ArrowRight, Sparkles, Zap, Shield } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-32">
        <div className="text-center">
          <div className="inline-flex items-center px-4 py-2 bg-blue-100 text-blue-800 rounded-full text-sm font-medium mb-8">
            <Sparkles className="w-4 h-4 mr-2" />
            Built with React, TypeScript & Tailwind CSS
          </div>
          
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">
            Beautiful Web
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              {' '}Applications
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 mb-12 max-w-3xl mx-auto leading-relaxed">
            Crafting exceptional digital experiences with modern technologies, 
            thoughtful design, and attention to every detail.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-16">
            <button className="group bg-gradient-to-r from-blue-600 to-purple-600 text-white px-8 py-4 rounded-xl font-semibold text-lg hover:shadow-lg hover:shadow-blue-500/25 transition-all duration-300 flex items-center">
              Get Started
              <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="bg-white text-gray-700 px-8 py-4 rounded-xl font-semibold text-lg border border-gray-200 hover:border-gray-300 hover:shadow-md transition-all duration-300">
              View Projects
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="flex items-center justify-center space-x-3 p-6 bg-white/60 backdrop-blur-sm rounded-2xl border border-gray-200">
              <Zap className="w-8 h-8 text-yellow-500" />
              <div className="text-left">
                <div className="font-bold text-gray-900">Lightning Fast</div>
                <div className="text-sm text-gray-600">Optimized Performance</div>
              </div>
            </div>
            
            <div className="flex items-center justify-center space-x-3 p-6 bg-white/60 backdrop-blur-sm rounded-2xl border border-gray-200">
              <Shield className="w-8 h-8 text-green-500" />
              <div className="text-left">
                <div className="font-bold text-gray-900">Type Safe</div>
                <div className="text-sm text-gray-600">TypeScript Powered</div>
              </div>
            </div>
            
            <div className="flex items-center justify-center space-x-3 p-6 bg-white/60 backdrop-blur-sm rounded-2xl border border-gray-200">
              <Sparkles className="w-8 h-8 text-purple-500" />
              <div className="text-left">
                <div className="font-bold text-gray-900">Modern Design</div>
                <div className="text-sm text-gray-600">Beautiful UI/UX</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;