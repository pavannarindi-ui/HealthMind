import React, { useState, useEffect } from 'react';
import { CheckCircle, Loader } from 'lucide-react';
import { getTranslation } from '../utils/translations';
import { ProcessingStep } from '../types';

interface ProcessingLoaderProps {
  language: string;
  onComplete: () => void;
}

const ProcessingLoader: React.FC<ProcessingLoaderProps> = ({ language, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [steps, setSteps] = useState<ProcessingStep[]>([
    {
      id: 'analyzing',
      label: getTranslation(language, 'processingSteps.analyzing'),
      completed: false,
      current: true
    },
    {
      id: 'diagnosing',
      label: getTranslation(language, 'processingSteps.diagnosing'),
      completed: false,
      current: false
    },
    {
      id: 'recommendations',
      label: getTranslation(language, 'processingSteps.recommendations'),
      completed: false,
      current: false
    },
    {
      id: 'medications',
      label: getTranslation(language, 'processingSteps.medications'),
      completed: false,
      current: false
    }
  ]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentStep(prev => {
        const nextStep = prev + 1;
        
        setSteps(prevSteps => 
          prevSteps.map((step, index) => ({
            ...step,
            completed: index < nextStep,
            current: index === nextStep
          }))
        );

        if (nextStep >= steps.length) {
          clearInterval(timer);
          setTimeout(onComplete, 1000);
          return prev;
        }

        return nextStep;
      });
    }, 2000);

    return () => clearInterval(timer);
  }, [onComplete, steps.length]);

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {getTranslation(language, 'processingTitle')}
        </h2>
      </div>

      <div className="space-y-4">
        {steps.map((step, index) => (
          <div
            key={step.id}
            className={`flex items-center p-4 rounded-xl transition-all duration-300 ${
              step.completed
                ? 'bg-green-50 border border-green-200'
                : step.current
                ? 'bg-blue-50 border border-blue-200'
                : 'bg-gray-50 border border-gray-200'
            }`}
          >
            <div className="flex-shrink-0 mr-4">
              {step.completed ? (
                <CheckCircle className="w-6 h-6 text-green-600" />
              ) : step.current ? (
                <Loader className="w-6 h-6 text-blue-600 animate-spin" />
              ) : (
                <div className="w-6 h-6 rounded-full border-2 border-gray-300" />
              )}
            </div>
            <div className="flex-1">
              <p className={`font-medium ${
                step.completed
                  ? 'text-green-900'
                  : step.current
                  ? 'text-blue-900'
                  : 'text-gray-600'
              }`}>
                {step.label}
              </p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 text-center">
        <div className="inline-block animate-pulse">
          <div className="flex space-x-1">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProcessingLoader;