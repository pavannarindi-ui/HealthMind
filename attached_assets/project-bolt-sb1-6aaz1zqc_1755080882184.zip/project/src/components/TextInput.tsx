import React, { useState } from 'react';
import { Send } from 'lucide-react';
import { getTranslation } from '../utils/translations';

interface TextInputProps {
  language: string;
  onSubmit: (text: string) => void;
  onBack: () => void;
}

const TextInput: React.FC<TextInputProps> = ({ language, onSubmit, onBack }) => {
  const [text, setText] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSubmit(text.trim());
    }
  };

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-lg">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          {getTranslation(language, 'textInputLabel')}
        </h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={getTranslation(language, 'textInputPlaceholder')}
            className="w-full h-40 p-4 border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:outline-none resize-none"
            required
          />
        </div>

        <div className="flex gap-4">
          <button
            type="button"
            onClick={onBack}
            className="flex-1 py-3 px-6 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
          >
            {getTranslation(language, 'back')}
          </button>
          <button
            type="submit"
            disabled={!text.trim()}
            className="flex-1 py-3 px-6 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
          >
            <Send className="w-5 h-5" />
            {getTranslation(language, 'continue')}
          </button>
        </div>
      </form>
    </div>
  );
};

export default TextInput;