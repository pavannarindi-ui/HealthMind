export const translations = {
  en: {
    // Language Selection
    selectLanguage: 'Select Your Language',
    languagePrompt: 'Please choose your preferred language for the healthcare assistant:',
    
    // Input Type Selection
    selectInputType: 'How would you like to describe your symptoms?',
    textInput: 'Type your symptoms',
    voiceInput: 'Record voice message',
    imageInput: 'Upload medical images',
    
    // Text Input
    textInputPlaceholder: 'Describe your symptoms in detail...',
    textInputLabel: 'Symptom Description',
    
    // Voice Input
    startRecording: 'Start Recording',
    stopRecording: 'Stop Recording',
    recordingInProgress: 'Recording in progress...',
    voiceInputLabel: 'Voice Recording',
    
    // Image Input
    uploadImages: 'Upload Medical Images',
    dragDropImages: 'Drag and drop images here or click to browse',
    imageInputLabel: 'Medical Images',
    
    // Processing
    processingTitle: 'Analyzing Your Symptoms',
    processingSteps: {
      analyzing: 'Analyzing symptoms...',
      diagnosing: 'Generating diagnosis...',
      recommendations: 'Preparing recommendations...',
      medications: 'Suggesting medications...'
    },
    
    // Results
    diagnosisTitle: 'Medical Assessment',
    recommendationsTitle: 'Recommendations',
    medicationsTitle: 'Suggested Medications',
    severityLevels: {
      low: 'Low Priority',
      medium: 'Medium Priority',
      high: 'High Priority - Seek immediate medical attention'
    },
    
    // Actions
    continue: 'Continue',
    back: 'Back',
    restart: 'Start Over',
    downloadSummary: 'Download Summary',
    
    // Common
    loading: 'Loading...',
    error: 'An error occurred. Please try again.',
    disclaimer: 'This is an AI-powered assessment and should not replace professional medical advice.'
  },
  
  hi: {
    // Language Selection
    selectLanguage: 'अपनी भाषा चुनें',
    languagePrompt: 'कृपया स्वास्थ्य सहायक के लिए अपनी पसंदीदा भाषा चुनें:',
    
    // Input Type Selection
    selectInputType: 'आप अपने लक्षणों का वर्णन कैसे करना चाहेंगे?',
    textInput: 'अपने लक्षण टाइप करें',
    voiceInput: 'आवाज़ संदेश रिकॉर्ड करें',
    imageInput: 'मेडिकल इमेज अपलोड करें',
    
    // Text Input
    textInputPlaceholder: 'अपने लक्षणों का विस्तार से वर्णन करें...',
    textInputLabel: 'लक्षण विवरण',
    
    // Voice Input
    startRecording: 'रिकॉर्डिंग शुरू करें',
    stopRecording: 'रिकॉर्डिंग बंद करें',
    recordingInProgress: 'रिकॉर्डिंग चल रही है...',
    voiceInputLabel: 'आवाज़ रिकॉर्डिंग',
    
    // Image Input
    uploadImages: 'मेडिकल इमेज अपलोड करें',
    dragDropImages: 'यहाँ इमेज खींचें और छोड़ें या ब्राउज़ करने के लिए क्लिक करें',
    imageInputLabel: 'मेडिकल इमेज',
    
    // Processing
    processingTitle: 'आपके लक्षणों का विश्लेषण',
    processingSteps: {
      analyzing: 'लक्षणों का विश्लेषण...',
      diagnosing: 'निदान तैयार कर रहे हैं...',
      recommendations: 'सुझाव तैयार कर रहे हैं...',
      medications: 'दवाओं का सुझाव दे रहे हैं...'
    },
    
    // Results
    diagnosisTitle: 'चिकित्सा मूल्यांकन',
    recommendationsTitle: 'सुझाव',
    medicationsTitle: 'सुझाई गई दवाएं',
    severityLevels: {
      low: 'कम प्राथमिकता',
      medium: 'मध्यम प्राथमिकता',
      high: 'उच्च प्राथमिकता - तुरंत चिकित्सा सहायता लें'
    },
    
    // Actions
    continue: 'जारी रखें',
    back: 'वापस',
    restart: 'फिर से शुरू करें',
    downloadSummary: 'सारांश डाउनलोड करें',
    
    // Common
    loading: 'लोड हो रहा है...',
    error: 'एक त्रुटि हुई है। कृपया पुनः प्रयास करें।',
    disclaimer: 'यह एक AI-संचालित मूल्यांकन है और पेशेवर चिकित्सा सलाह का विकल्प नहीं है।'
  },
  
  ta: {
    // Language Selection
    selectLanguage: 'உங்கள் மொழியைத் தேர்ந்தெடுக்கவும்',
    languagePrompt: 'சுகாதார உதவியாளருக்கு உங்கள் விருப்பமான மொழியைத் தேர்ந்தெடுக்கவும்:',
    
    // Input Type Selection
    selectInputType: 'உங்கள் அறிகுறிகளை எவ்வாறு விவரிக்க விரும்புகிறீர்கள்?',
    textInput: 'உங்கள் அறிகுறிகளை தட்டச்சு செய்யுங்கள்',
    voiceInput: 'குரல் செய்தியை பதிவு செய்யுங்கள்',
    imageInput: 'மருத்துவ படங்களை பதிவேற்றுங்கள்',
    
    // Text Input
    textInputPlaceholder: 'உங்கள் அறிகுறிகளை விரிவாக விவரிக்கவும்...',
    textInputLabel: 'அறிகுறி விவரம்',
    
    // Voice Input
    startRecording: 'பதிவு தொடங்கு',
    stopRecording: 'பதிவு நிறுத்து',
    recordingInProgress: 'பதிவு நடைபெற்று கொண்டிருக்கிறது...',
    voiceInputLabel: 'குரல் பதிவு',
    
    // Image Input
    uploadImages: 'மருத்துவ படங்களை பதிவேற்றுங்கள்',
    dragDropImages: 'படங்களை இங்கே இழுத்து விடுங்கள் அல்லது உலாவ கிளிக் செய்யுங்கள்',
    imageInputLabel: 'மருத்துவ படங்கள்',
    
    // Processing
    processingTitle: 'உங்கள் அறிகுறிகளை பகுப்பாய்வு செய்கிறது',
    processingSteps: {
      analyzing: 'அறிகுறிகளை பகுப்பாய்வு செய்கிறது...',
      diagnosing: 'நோயறிதலை உருவாக்குகிறது...',
      recommendations: 'பரிந்துரைகளை தயாரிக்கிறது...',
      medications: 'மருந்துகளை பரிந்துரைக்கிறது...'
    },
    
    // Results
    diagnosisTitle: 'மருத்துவ மதிப்பீடு',
    recommendationsTitle: 'பரிந்துரைகள்',
    medicationsTitle: 'பரிந்துரைக்கப்பட்ட மருந்துகள்',
    severityLevels: {
      low: 'குறைந்த முன்னுரிமை',
      medium: 'நடுத்தர முன்னுரிமை',
      high: 'அதிக முன்னுரிமை - உடனடி மருத்துவ உதவி பெறுங்கள்'
    },
    
    // Actions
    continue: 'தொடரவும்',
    back: 'பின்னால்',
    restart: 'மீண்டும் தொடங்கு',
    downloadSummary: 'சுருக்கத்தை பதிவிறக்கு',
    
    // Common
    loading: 'ஏற்றுகிறது...',
    error: 'ஒரு பிழை ஏற்பட்டது. தயவுசெய்து மீண்டும் முயற்சிக்கவும்.',
    disclaimer: 'இது AI-இயங்கும் மதிப்பீடு மற்றும் தொழில்முறை மருத்துவ ஆலோசனையை மாற்றக்கூடாது.'
  },
  
  te: {
    // Language Selection
    selectLanguage: 'మీ భాషను ఎంచుకోండి',
    languagePrompt: 'ఆరోగ్య సహాయకుడి కోసం మీ ఇష్టమైన భాషను ఎంచుకోండి:',
    
    // Input Type Selection
    selectInputType: 'మీ లక్షణాలను ఎలా వివరించాలని అనుకుంటున్నారు?',
    textInput: 'మీ లక్షణాలను టైప్ చేయండి',
    voiceInput: 'వాయిస్ మెసేజ్ రికార్డ్ చేయండి',
    imageInput: 'వైద్య చిత్రాలను అప్‌లోడ్ చేయండి',
    
    // Text Input
    textInputPlaceholder: 'మీ లక్షణాలను వివరంగా వివరించండి...',
    textInputLabel: 'లక్షణ వివరణ',
    
    // Voice Input
    startRecording: 'రికార్డింగ్ ప్రారంభించండి',
    stopRecording: 'రికార్డింగ్ ఆపండి',
    recordingInProgress: 'రికార్డింగ్ జరుగుతోంది...',
    voiceInputLabel: 'వాయిస్ రికార్డింగ్',
    
    // Image Input
    uploadImages: 'వైద్య చిత్రాలను అప్‌లోడ్ చేయండి',
    dragDropImages: 'చిత్రాలను ఇక్కడ లాగి వదలండి లేదా బ్రౌజ్ చేయడానికి క్లిక్ చేయండి',
    imageInputLabel: 'వైద్య చిత్రాలు',
    
    // Processing
    processingTitle: 'మీ లక్షణాలను విశ్లేషిస్తోంది',
    processingSteps: {
      analyzing: 'లక్షణాలను విశ్లేషిస్తోంది...',
      diagnosing: 'రోగ నిర్ధారణను రూపొందిస్తోంది...',
      recommendations: 'సిఫార్సులను తయారు చేస్తోంది...',
      medications: 'మందులను సూచిస్తోంది...'
    },
    
    // Results
    diagnosisTitle: 'వైద్య మూల్యాంకనం',
    recommendationsTitle: 'సిఫార్సులు',
    medicationsTitle: 'సూచించిన మందులు',
    severityLevels: {
      low: 'తక్కువ ప్రాధాన్యత',
      medium: 'మధ్యస్థ ప్రాధాన్యత',
      high: 'అధిక ప్రాధాన్యత - వెంటనే వైద్య సహాయం పొందండి'
    },
    
    // Actions
    continue: 'కొనసాగించు',
    back: 'వెనుకకు',
    restart: 'మళ్లీ ప్రారంభించు',
    downloadSummary: 'సారాంశం డౌన్‌లోడ్ చేయండి',
    
    // Common
    loading: 'లోడ్ అవుతోంది...',
    error: 'లోపం సంభవించింది. దయచేసి మళ్లీ ప్రయత్నించండి.',
    disclaimer: 'ఇది AI-శక్తితో కూడిన మూల్యాంకనం మరియు వృత్తిపరమైన వైద్య సలహాను భర్తీ చేయకూడదు.'
  },
  
  bn: {
    // Language Selection
    selectLanguage: 'আপনার ভাষা নির্বাচন করুন',
    languagePrompt: 'স্বাস্থ্য সহায়কের জন্য আপনার পছন্দের ভাষা নির্বাচন করুন:',
    
    // Input Type Selection
    selectInputType: 'আপনি কীভাবে আপনার লক্ষণগুলি বর্ণনা করতে চান?',
    textInput: 'আপনার লক্ষণগুলি টাইপ করুন',
    voiceInput: 'ভয়েস বার্তা রেকর্ড করুন',
    imageInput: 'চিকিৎসা ছবি আপলোড করুন',
    
    // Text Input
    textInputPlaceholder: 'আপনার লক্ষণগুলি বিস্তারিতভাবে বর্ণনা করুন...',
    textInputLabel: 'লক্ষণ বিবরণ',
    
    // Voice Input
    startRecording: 'রেকর্ডিং শুরু করুন',
    stopRecording: 'রেকর্ডিং বন্ধ করুন',
    recordingInProgress: 'রেকর্ডিং চলছে...',
    voiceInputLabel: 'ভয়েস রেকর্ডিং',
    
    // Image Input
    uploadImages: 'চিকিৎসা ছবি আপলোড করুন',
    dragDropImages: 'এখানে ছবি টেনে আনুন বা ব্রাউজ করতে ক্লিক করুন',
    imageInputLabel: 'চিকিৎসা ছবি',
    
    // Processing
    processingTitle: 'আপনার লক্ষণগুলি বিশ্লেষণ করা হচ্ছে',
    processingSteps: {
      analyzing: 'লক্ষণগুলি বিশ্লেষণ করা হচ্ছে...',
      diagnosing: 'রোগ নির্ণয় তৈরি করা হচ্ছে...',
      recommendations: 'সুপারিশ প্রস্তুত করা হচ্ছে...',
      medications: 'ওষুধের পরামর্শ দেওয়া হচ্ছে...'
    },
    
    // Results
    diagnosisTitle: 'চিকিৎসা মূল্যায়ন',
    recommendationsTitle: 'সুপারিশ',
    medicationsTitle: 'প্রস্তাবিত ওষুধ',
    severityLevels: {
      low: 'কম অগ্রাধিকার',
      medium: 'মাঝারি অগ্রাধিকার',
      high: 'উচ্চ অগ্রাধিকার - অবিলম্বে চিকিৎসা সহায়তা নিন'
    },
    
    // Actions
    continue: 'চালিয়ে যান',
    back: 'পিছনে',
    restart: 'আবার শুরু করুন',
    downloadSummary: 'সারসংক্ষেপ ডাউনলোড করুন',
    
    // Common
    loading: 'লোড হচ্ছে...',
    error: 'একটি ত্রুটি ঘটেছে। অনুগ্রহ করে আবার চেষ্টা করুন।',
    disclaimer: 'এটি একটি AI-চালিত মূল্যায়ন এবং পেশাদার চিকিৎসা পরামর্শের বিকল্প হওয়া উচিত নয়।'
  },
  
  ml: {
    // Language Selection
    selectLanguage: 'നിങ്ങളുടെ ഭാഷ തിരഞ്ഞെടുക്കുക',
    languagePrompt: 'ആരോഗ്യ സഹായിക്കായി നിങ്ങളുടെ ഇഷ്ടമുള്ള ഭാഷ തിരഞ്ഞെടുക്കുക:',
    
    // Input Type Selection
    selectInputType: 'നിങ്ങളുടെ ലക്ഷണങ്ങൾ എങ്ങനെ വിവരിക്കാൻ ആഗ്രഹിക്കുന്നു?',
    textInput: 'നിങ്ങളുടെ ലക്ഷണങ്ങൾ ടൈപ്പ് ചെയ്യുക',
    voiceInput: 'വോയ്‌സ് സന്ദേശം റെക്കോർഡ് ചെയ്യുക',
    imageInput: 'മെഡിക്കൽ ചിത്രങ്ങൾ അപ്‌ലോഡ് ചെയ്യുക',
    
    // Text Input
    textInputPlaceholder: 'നിങ്ങളുടെ ലക്ഷണങ്ങൾ വിശദമായി വിവരിക്കുക...',
    textInputLabel: 'ലക്ഷണ വിവരണം',
    
    // Voice Input
    startRecording: 'റെക്കോർഡിംഗ് ആരംഭിക്കുക',
    stopRecording: 'റെക്കോർഡിംഗ് നിർത്തുക',
    recordingInProgress: 'റെക്കോർഡിംഗ് പുരോഗതിയിൽ...',
    voiceInputLabel: 'വോയ്‌സ് റെക്കോർഡിംഗ്',
    
    // Image Input
    uploadImages: 'മെഡിക്കൽ ചിത്രങ്ങൾ അപ്‌ലോഡ് ചെയ്യുക',
    dragDropImages: 'ചിത്രങ്ങൾ ഇവിടെ വലിച്ചിടുക അല്ലെങ്കിൽ ബ്രൗസ് ചെയ്യാൻ ക്ലിക്ക് ചെയ്യുക',
    imageInputLabel: 'മെഡിക്കൽ ചിത്രങ്ങൾ',
    
    // Processing
    processingTitle: 'നിങ്ങളുടെ ലക്ഷണങ്ങൾ വിശകലനം ചെയ്യുന്നു',
    processingSteps: {
      analyzing: 'ലക്ഷണങ്ങൾ വിശകലനം ചെയ്യുന്നു...',
      diagnosing: 'രോഗനിർണയം സൃഷ്ടിക്കുന്നു...',
      recommendations: 'ശുപാർശകൾ തയ്യാറാക്കുന്നു...',
      medications: 'മരുന്നുകൾ നിർദ്ദേശിക്കുന്നു...'
    },
    
    // Results
    diagnosisTitle: 'മെഡിക്കൽ വിലയിരുത്തൽ',
    recommendationsTitle: 'ശുപാർശകൾ',
    medicationsTitle: 'നിർദ്ദേശിച്ച മരുന്നുകൾ',
    severityLevels: {
      low: 'കുറഞ്ഞ മുൻഗണന',
      medium: 'ഇടത്തരം മുൻഗണന',
      high: 'ഉയർന്ന മുൻഗണന - ഉടനടി വൈദ്യസഹായം തേടുക'
    },
    
    // Actions
    continue: 'തുടരുക',
    back: 'പിന്നോട്ട്',
    restart: 'വീണ്ടും ആരംഭിക്കുക',
    downloadSummary: 'സംഗ്രഹം ഡൗൺലോഡ് ചെയ്യുക',
    
    // Common
    loading: 'ലോഡ് ചെയ്യുന്നു...',
    error: 'ഒരു പിശക് സംഭവിച്ചു. ദയവായി വീണ്ടും ശ്രമിക്കുക.',
    disclaimer: 'ഇത് AI-പവർഡ് വിലയിരുത്തലാണ്, പ്രൊഫഷണൽ മെഡിക്കൽ ഉപദേശത്തിന് പകരമാകരുത്.'
  }
};

export const getTranslation = (language: string, key: string): string => {
  const keys = key.split('.');
  let value: any = translations[language as keyof typeof translations] || translations.en;
  
  for (const k of keys) {
    value = value?.[k];
  }
  
  return value || key;
};