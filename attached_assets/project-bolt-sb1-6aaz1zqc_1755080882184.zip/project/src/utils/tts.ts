export class TextToSpeechService {
  private synthesis: SpeechSynthesis;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    this.synthesis = window.speechSynthesis;
  }

  speak(text: string, language: string = 'en'): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.synthesis) {
        reject(new Error('Speech synthesis not supported'));
        return;
      }

      // Stop any current speech
      this.stop();

      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      // Set language-specific voice
      const voices = this.synthesis.getVoices();
      const voice = this.findVoiceForLanguage(voices, language);
      if (voice) {
        utterance.voice = voice;
      }

      utterance.lang = this.getLanguageCode(language);
      utterance.rate = 0.9;
      utterance.pitch = 1;
      utterance.volume = 1;

      utterance.onend = () => {
        this.currentUtterance = null;
        resolve();
      };

      utterance.onerror = (event) => {
        this.currentUtterance = null;
        reject(new Error(`Speech synthesis error: ${event.error}`));
      };

      this.synthesis.speak(utterance);
    });
  }

  stop(): void {
    if (this.synthesis && this.synthesis.speaking) {
      this.synthesis.cancel();
    }
    this.currentUtterance = null;
  }

  isSpeaking(): boolean {
    return this.synthesis?.speaking || false;
  }

  private findVoiceForLanguage(voices: SpeechSynthesisVoice[], language: string): SpeechSynthesisVoice | null {
    const langCode = this.getLanguageCode(language);
    
    // Try to find exact match
    let voice = voices.find(v => v.lang.toLowerCase() === langCode.toLowerCase());
    
    // Try to find partial match (e.g., 'en' matches 'en-US')
    if (!voice) {
      const baseLang = langCode.split('-')[0];
      voice = voices.find(v => v.lang.toLowerCase().startsWith(baseLang.toLowerCase()));
    }
    
    return voice || null;
  }

  private getLanguageCode(language: string): string {
    const languageCodes: { [key: string]: string } = {
      'en': 'en-US',
      'hi': 'hi-IN',
      'ta': 'ta-IN',
      'te': 'te-IN',
      'bn': 'bn-IN',
      'ml': 'ml-IN'
    };
    
    return languageCodes[language] || 'en-US';
  }

  getAvailableVoices(): SpeechSynthesisVoice[] {
    return this.synthesis?.getVoices() || [];
  }
}

export const ttsService = new TextToSpeechService();