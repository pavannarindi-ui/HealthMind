import { DiagnosisResult } from '../types';

// Mock AI service for healthcare diagnosis
export class MockHealthcareAI {
  private static readonly MOCK_DELAY = 3000; // 3 seconds

  static async analyzeSymptoms(
    symptoms: string,
    language: string = 'en',
    images?: File[]
  ): Promise<DiagnosisResult> {
    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, this.MOCK_DELAY));

    // Mock diagnosis based on common symptoms
    const mockDiagnoses = this.getMockDiagnoses(language);
    const selectedDiagnosis = this.selectDiagnosisBasedOnSymptoms(symptoms, mockDiagnoses);
    
    return selectedDiagnosis;
  }

  private static getMockDiagnoses(language: string): DiagnosisResult[] {
    const diagnoses = {
      en: [
        {
          condition: 'Common Cold',
          confidence: 0.85,
          symptoms: ['runny nose', 'sneezing', 'mild fever', 'cough'],
          recommendations: [
            'Get plenty of rest',
            'Stay hydrated',
            'Use a humidifier',
            'Consider over-the-counter medications for symptom relief'
          ],
          medications: ['Paracetamol', 'Decongestants', 'Cough syrup'],
          severity: 'low' as const
        },
        {
          condition: 'Seasonal Allergies',
          confidence: 0.78,
          symptoms: ['sneezing', 'itchy eyes', 'runny nose', 'congestion'],
          recommendations: [
            'Avoid known allergens',
            'Keep windows closed during high pollen days',
            'Use air purifiers',
            'Consider antihistamines'
          ],
          medications: ['Antihistamines', 'Nasal sprays', 'Eye drops'],
          severity: 'low' as const
        },
        {
          condition: 'Migraine',
          confidence: 0.82,
          symptoms: ['severe headache', 'nausea', 'sensitivity to light', 'dizziness'],
          recommendations: [
            'Rest in a dark, quiet room',
            'Apply cold compress to head',
            'Stay hydrated',
            'Avoid triggers like stress and certain foods'
          ],
          medications: ['Ibuprofen', 'Sumatriptan', 'Anti-nausea medication'],
          severity: 'medium' as const
        }
      ],
      hi: [
        {
          condition: 'सामान्य सर्दी',
          confidence: 0.85,
          symptoms: ['बहती नाक', 'छींकना', 'हल्का बुखार', 'खांसी'],
          recommendations: [
            'पर्याप्त आराम करें',
            'हाइड्रेटेड रहें',
            'ह्यूमिडिफायर का उपयोग करें',
            'लक्षण राहत के लिए ओवर-द-काउंटर दवाओं पर विचार करें'
          ],
          medications: ['पैरासिटामोल', 'डिकंजेस्टेंट', 'खांसी की सिरप'],
          severity: 'low' as const
        }
      ],
      ta: [
        {
          condition: 'பொதுவான சளி',
          confidence: 0.85,
          symptoms: ['மூக்கு ஒழுகுதல்', 'தும்மல்', 'லேசான காய்ச்சல்', 'இருமல்'],
          recommendations: [
            'போதுமான ஓய்வு எடுங்கள்',
            'நீர்ச்சத்துடன் இருங்கள்',
            'ஈரப்பதமூட்டியைப் பயன்படுத்துங்கள்',
            'அறிகுறி நிவாரணத்திற்கு மருந்துகளைக் கருத்தில் கொள்ளுங்கள்'
          ],
          medications: ['பாராசிட்டமால்', 'நெரிசல் நீக்கிகள்', 'இருமல் சிரப்'],
          severity: 'low' as const
        }
      ],
      te: [
        {
          condition: 'సాధారణ జలుబు',
          confidence: 0.85,
          symptoms: ['ముక్కు కారడం', 'తుమ్మడం', 'తేలికపాటి జ్వరం', 'దగ్గు'],
          recommendations: [
            'తగినంత విశ్రాంతి తీసుకోండి',
            'హైడ్రేటెడ్‌గా ఉండండి',
            'హ్యూమిడిఫైయర్ ఉపయోగించండి',
            'లక్షణ ఉపశమనం కోసం మందులను పరిగణించండి'
          ],
          medications: ['పారాసిటమాల్', 'డీకంజెస్టెంట్స్', 'దగ్గు సిరప్'],
          severity: 'low' as const
        }
      ],
      bn: [
        {
          condition: 'সাধারণ সর্দি',
          confidence: 0.85,
          symptoms: ['নাক দিয়ে পানি পড়া', 'হাঁচি', 'হালকা জ্বর', 'কাশি'],
          recommendations: [
            'পর্যাপ্ত বিশ্রাম নিন',
            'হাইড্রেটেড থাকুন',
            'হিউমিডিফায়ার ব্যবহার করুন',
            'লক্ষণ উপশমের জন্য ওষুধ বিবেচনা করুন'
          ],
          medications: ['প্যারাসিটামল', 'ডিকনজেস্ট্যান্ট', 'কাশির সিরাপ'],
          severity: 'low' as const
        }
      ],
      ml: [
        {
          condition: 'സാധാരണ ജലദോഷം',
          confidence: 0.85,
          symptoms: ['മൂക്കൊലിപ്പ്', 'തുമ്മൽ', 'നേരിയ പനി', 'ചുമ'],
          recommendations: [
            'വേണ്ടത്ര വിശ്രമിക്കുക',
            'ജലാംശം നിലനിർത്തുക',
            'ഹ്യൂമിഡിഫയർ ഉപയോഗിക്കുക',
            'ലക്ഷണ ആശ്വാസത്തിനായി മരുന്നുകൾ പരിഗണിക്കുക'
          ],
          medications: ['പാരസെറ്റമോൾ', 'ഡീകൺജെസ്റ്റന്റുകൾ', 'ചുമ സിറപ്പ്'],
          severity: 'low' as const
        }
      ]
    };

    return diagnoses[language as keyof typeof diagnoses] || diagnoses.en;
  }

  private static selectDiagnosisBasedOnSymptoms(symptoms: string, diagnoses: DiagnosisResult[]): DiagnosisResult {
    const lowerSymptoms = symptoms.toLowerCase();
    
    // Simple keyword matching for demo purposes
    if (lowerSymptoms.includes('headache') || lowerSymptoms.includes('migraine')) {
      return diagnoses.find(d => d.condition.toLowerCase().includes('migraine')) || diagnoses[0];
    }
    
    if (lowerSymptoms.includes('allergy') || lowerSymptoms.includes('itchy')) {
      return diagnoses.find(d => d.condition.toLowerCase().includes('allerg')) || diagnoses[0];
    }
    
    // Default to first diagnosis (common cold)
    return diagnoses[0];
  }

  static async processVoiceInput(audioBlob: Blob, language: string = 'en'): Promise<string> {
    // Simulate voice-to-text processing
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockTranscriptions = {
      en: "I have been experiencing headache and nausea for the past two days. The pain is severe and I feel dizzy.",
      hi: "मुझे पिछले दो दिनों से सिरदर्द और मतली हो रही है। दर्द गंभीर है और मुझे चक्कर आ रहे हैं।",
      ta: "கடந்த இரண்டு நாட்களாக எனக்கு தலைவலி மற்றும் குமட்டல் இருக்கிறது। வலி கடுமையானது மற்றும் எனக்கு தலைசுற்றல் உள்ளது।",
      te: "గత రెండు రోజులుగా నాకు తలనొప్పి మరియు వికారం వస్తోంది. నొప్పి తీవ్రంగా ఉంది మరియు నాకు తలతిరుగుతోంది।",
      bn: "গত দুই দিন ধরে আমার মাথাব্যথা এবং বমি বমি ভাব হচ্ছে। ব্যথা তীব্র এবং আমার মাথা ঘোরাচ্ছে।",
      ml: "കഴിഞ്ഞ രണ്ട് ദിവസമായി എനിക്ക് തലവേദനയും ഓക്കാനവും അനുഭവപ്പെടുന്നു. വേദന കഠിനമാണ്, എനിക്ക് തലകറക്കം തോന്നുന്നു।"
    };
    
    return mockTranscriptions[language as keyof typeof mockTranscriptions] || mockTranscriptions.en;
  }

  static async processImageInput(images: File[], language: string = 'en'): Promise<string> {
    // Simulate image analysis
    await new Promise(resolve => setTimeout(resolve, 4000));
    
    const mockImageAnalysis = {
      en: "Based on the uploaded images, I can see signs of skin irritation with redness and mild swelling. This appears to be consistent with an allergic reaction or contact dermatitis.",
      hi: "अपलोड की गई छवियों के आधार पर, मैं लालिमा और हल्की सूजन के साथ त्वचा की जलन के संकेत देख सकता हूं। यह एलर्जी प्रतिक्रिया या संपर्क त्वचाशोथ के अनुरूप प्रतीत होता है।",
      ta: "பதிவேற்றப்பட்ட படங்களின் அடிப்படையில், சிவப்பு நிறம் மற்றும் லேசான வீக்கத்துடன் தோல் எரிச்சலின் அறிகுறிகளை என்னால் காண முடிகிறது। இது ஒவ்வாமை எதிர்வினை அல்லது தொடர்பு தோல் அழற்சியுடன் ஒத்துப்போகிறது।",
      te: "అప్‌లోడ్ చేసిన చిత్రాల ఆధారంగా, ఎరుపు రంగు మరియు తేలికపాటి వాపుతో చర్మ చికాకు సంకేతాలను నేను చూడగలను. ఇది అలెర్జీ ప్రతిచర్య లేదా కాంటాక్ట్ డెర్మటైటిస్‌తో స్థిరంగా కనిపిస్తుంది।",
      bn: "আপলোড করা ছবিগুলির উপর ভিত্তি করে, আমি লালভাব এবং হালকা ফোলা সহ ত্বকের জ্বালার লক্ষণ দেখতে পাচ্ছি। এটি অ্যালার্জির প্রতিক্রিয়া বা যোগাযোগ ডার্মাটাইটিসের সাথে সামঞ্জস্যপূর্ণ বলে মনে হচ্ছে।",
      ml: "അപ്‌ലോഡ് ചെയ്ത ചിത്രങ്ങളുടെ അടിസ്ഥാനത്തിൽ, ചുവപ്പും നേരിയ വീക്കവുമുള്ള ചർമ്മ പ്രകോപനത്തിന്റെ ലക്ഷണങ്ങൾ എനിക്ക് കാണാൻ കഴിയും. ഇത് അലർജി പ്രതികരണം അല്ലെങ്കിൽ കോൺടാക്റ്റ് ഡെർമറ്റൈറ്റിസുമായി പൊരുത്തപ്പെടുന്നതായി തോന്നുന്നു."
    };
    
    return mockImageAnalysis[language as keyof typeof mockImageAnalysis] || mockImageAnalysis.en;
  }
}