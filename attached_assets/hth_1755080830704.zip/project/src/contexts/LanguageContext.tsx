import React, { createContext, useContext, useState, ReactNode } from 'react';

interface LanguageContextType {
  language: string;
  setLanguage: (lang: string) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<string, Record<string, string>> = {
  en: {
    // Navigation & General
    dashboard: 'Dashboard',
    symptomChecker: 'Symptom Checker',
    medicineScanner: 'Medicine Scanner',
    voiceAssistant: 'Voice Assistant',
    followUp: 'Follow-up',
    healthTimeline: 'Health Timeline',
    settings: 'Settings',
    back: 'Back',
    home: 'Home',
    timeline: 'Timeline',
    voice: 'Voice',
    profile: 'Profile',
    online: 'Online',
    offline: 'Offline',
    
    // Dashboard
    welcomeBack: 'Welcome back!',
    howFeeling: 'How are you feeling today?',
    consultations: 'Consultations',
    healthScore: 'Health Score',
    achievements: 'Achievements',
    community: 'Community',
    quickActions: 'Quick Actions',
    recentActivity: 'Recent Activity',
    
    // Symptom Checker
    describeSymptoms: 'Describe your symptoms',
    scanMedicine: 'Scan medicine for info',
    speakToAI: 'Speak to AI assistant',
    checkProgress: 'Check your progress',
    emergencyWarning: 'Emergency Symptoms',
    emergencyDescription: 'If you experience any of these symptoms, seek immediate medical attention:',
    chestPain: 'Chest pain',
    breathingDifficulty: 'Difficulty breathing',
    severeHeadache: 'Severe headache',
    suddenWeakness: 'Sudden weakness',
    symptomConversation: 'Symptom Conversation',
    typeSymptoms: 'Type your symptoms here...',
    analyzingMedicine: 'Analyzing medicine...',
    analysisError: 'Sorry, I could not analyze your symptoms at this time.',
    
    // Medicine Scanner
    scanMedicineDescription: 'Take a photo of your medicine to get detailed information about dosage, interactions, and side effects.',
    uploadMedicinePhoto: 'Upload Medicine Photo',
    photoInstructions: 'Take a clear photo of the medicine label or pill',
    takePhoto: 'Take Photo',
    uploadPhoto: 'Upload Photo',
    retakePhoto: 'Retake Photo',
    scanning: 'Scanning...',
    medicineIdentified: 'Medicine Identified',
    genericName: 'Generic Name',
    dosageInformation: 'Dosage Information',
    dosage: 'Dosage',
    frequency: 'Frequency',
    warnings: 'Warnings',
    drugInteractions: 'Drug Interactions',
    sideEffects: 'Side Effects',
    saveToProfile: 'Save to Profile',
    shareWithDoctor: 'Share with Doctor',
    
    // Voice Assistant
    voiceAssistantDescription: 'Speak naturally about your health concerns in your preferred language',
    youSaid: 'You said',
    speakingIn: 'Speaking in',
    howToUse: 'How to use',
    tapMicToStart: 'Tap microphone to start recording',
    speakClearly: 'Speak clearly about your symptoms',
    tapAgainToStop: 'Tap again to stop recording',
    aiWillRespond: 'AI will analyze and respond',
    conversation: 'Conversation',
    playAudio: 'Play Audio',
    
    // Follow-up System
    followUpSystem: 'Smart Follow-up System',
    followUpDescription: 'AI-powered follow-ups help track your recovery and ensure proper care',
    pending: 'Pending',
    completed: 'Completed',
    improved: 'Improved',
    needAttention: 'Need Attention',
    followUpCompleted: 'Follow-up check completed',
    medicineScanned: 'Medicine information updated',
    symptomCheckCompleted: 'Symptom assessment completed',
    followUpCheck: 'Follow-up Check',
    originalSymptom: 'Original Symptom',
    scheduled: 'Scheduled',
    mild: 'Mild',
    moderate: 'Moderate',
    severe: 'Severe',
    howFeelingNow: 'How are you feeling now?',
    better: 'Better',
    same: 'Same',
    worse: 'Worse',
    additionalNotes: 'Additional Notes',
    shareAnyChanges: 'Share any changes or new symptoms...',
    submitFollowUp: 'Submit Follow-up',
    checkIn: 'Check In',
    status: 'Status',
    pendingFollowUps: 'Pending Follow-ups',
    due: 'Due',
    complete: 'Complete',
    
    // Health Timeline
    trackYourProgress: 'Track your health journey and celebrate improvements',
    weeklyImprovement: 'Weekly Trend',
    assessmentProgress: 'Assessment Progress',
    
    // Settings
    language: 'Language',
    personalInfo: 'Personal Information',
    medicalHistory: 'Medical History',
    emergencyContacts: 'Emergency Contacts',
    preferences: 'Preferences',
    notifications: 'Notifications',
    followUpReminders: 'Follow-up Reminders',
    healthGoals: 'Health Goals',
    privacy: 'Privacy & Security',
    dataSharing: 'Data Sharing',
    anonymousMode: 'Anonymous Mode',
    exportData: 'Export Data',
    accessibility: 'Accessibility',
    voiceSettings: 'Voice Settings',
    textSize: 'Text Size',
    colorContrast: 'Color Contrast',
    offlineMode: 'Offline Mode Ready',
    offlineDescription: 'Download essential data for offline access in remote areas',
    downloadOfflineData: 'Download Offline Data',
    healthPlatform: 'Health Platform'
  },
  es: {
    dashboard: 'Tablero',
    symptomChecker: 'Verificador de Síntomas',
    medicineScanner: 'Escáner de Medicinas',
    voiceAssistant: 'Asistente de Voz',
    welcomeBack: '¡Bienvenido de vuelta!',
    howFeeling: '¿Cómo te sientes hoy?',
    describeSymptoms: 'Describe tus síntomas',
    scanMedicine: 'Escanea medicina para información',
    speakToAI: 'Habla con el asistente IA',
    checkProgress: 'Verifica tu progreso',
    // Add more Spanish translations...
  },
  fr: {
    dashboard: 'Tableau de bord',
    symptomChecker: 'Vérificateur de Symptômes',
    medicineScanner: 'Scanner de Médicaments',
    voiceAssistant: 'Assistant Vocal',
    welcomeBack: 'Bon retour !',
    howFeeling: 'Comment vous sentez-vous aujourd\'hui ?',
    // Add more French translations...
  },
  ar: {
    dashboard: 'لوحة التحكم',
    symptomChecker: 'فاحص الأعراض',
    medicineScanner: 'ماسح الأدوية',
    voiceAssistant: 'مساعد صوتي',
    welcomeBack: 'أهلاً بعودتك!',
    howFeeling: 'كيف تشعر اليوم؟',
    // Add more Arabic translations...
  },
  hi: {
    dashboard: 'डैशबोर्ड',
    symptomChecker: 'लक्षण जांचकर्ता',
    medicineScanner: 'दवा स्कैनर',
    voiceAssistant: 'आवाज सहायक',
    welcomeBack: 'वापसी पर स्वागत है!',
    howFeeling: 'आज आप कैसा महसूस कर रहे हैं?',
    // Add more Hindi translations...
  }
};

interface LanguageProviderProps {
  children: ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState('en');

  const t = (key: string): string => {
    return translations[language]?.[key] || translations.en[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}