interface FollowUp {
  id: string;
  symptom: string;
  severity: 'mild' | 'moderate' | 'severe';
  scheduledDate: Date;
  status: 'pending' | 'completed' | 'missed';
  improvement: 'better' | 'same' | 'worse' | null;
  notes: string;
}

export class FollowUpService {
  static async getFollowUps(): Promise<FollowUp[]> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: '1',
        symptom: 'Persistent cough with chest tightness',
        severity: 'moderate',
        scheduledDate: new Date(Date.now()),
        status: 'pending',
        improvement: null,
        notes: ''
      },
      {
        id: '2',
        symptom: 'Afternoon headaches',
        severity: 'mild',
        scheduledDate: new Date(Date.now() - 86400000),
        status: 'completed',
        improvement: 'better',
        notes: 'Much improved after increasing water intake'
      },
      {
        id: '3',
        symptom: 'Joint pain in knees',
        severity: 'mild',
        scheduledDate: new Date(Date.now() + 86400000),
        status: 'pending',
        improvement: null,
        notes: ''
      },
      {
        id: '4',
        symptom: 'Stomach upset and nausea',
        severity: 'moderate',
        scheduledDate: new Date(Date.now() - 172800000),
        status: 'completed',
        improvement: 'same',
        notes: 'Symptoms persist, may need medical consultation'
      }
    ];
  }

  static async completeFollowUp(
    id: string, 
    improvement: 'better' | 'same' | 'worse',
    notes: string
  ): Promise<void> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // In a real app, this would update the backend
    console.log(`Follow-up ${id} completed:`, { improvement, notes });
  }

  static async scheduleFollowUp(
    symptom: string,
    severity: 'mild' | 'moderate' | 'severe',
    hoursFromNow: number = 24
  ): Promise<string> {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const followUpId = Math.random().toString(36).substr(2, 9);
    console.log(`Scheduled follow-up ${followUpId} for: ${symptom}`);
    
    return followUpId;
  }
}