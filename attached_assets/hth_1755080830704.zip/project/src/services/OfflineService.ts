export class OfflineService {
  private static readonly STORAGE_KEY = 'telemedicine_offline_data';

  static init(): void {
    // Initialize offline capabilities
    if ('serviceWorker' in navigator) {
      this.registerServiceWorker();
    }
    
    this.initializeOfflineData();
  }

  private static async registerServiceWorker(): Promise<void> {
    try {
      // In a real implementation, register service worker for offline caching
      console.log('Service worker support detected');
    } catch (error) {
      console.log('Service worker registration failed:', error);
    }
  }

  private static initializeOfflineData(): void {
    const offlineData = {
      symptoms: [
        'fever', 'cough', 'headache', 'nausea', 'fatigue',
        'chest pain', 'shortness of breath', 'dizziness'
      ],
      commonMedicines: [
        { name: 'Ibuprofen', dosage: '200mg', frequency: 'Every 4-6 hours' },
        { name: 'Paracetamol', dosage: '500mg', frequency: 'Every 4-6 hours' },
        { name: 'Aspirin', dosage: '325mg', frequency: 'Every 4 hours' }
      ],
      emergencyContacts: [
        { name: 'Local Emergency', number: '911' },
        { name: 'Poison Control', number: '1-800-222-1222' },
        { name: 'Mental Health Crisis', number: '988' }
      ],
      lastSync: new Date().toISOString()
    };

    if (!localStorage.getItem(this.STORAGE_KEY)) {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(offlineData));
    }
  }

  static getOfflineData(): any {
    const data = localStorage.getItem(this.STORAGE_KEY);
    return data ? JSON.parse(data) : null;
  }

  static updateOfflineData(newData: any): void {
    const existingData = this.getOfflineData() || {};
    const updatedData = { ...existingData, ...newData, lastSync: new Date().toISOString() };
    localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedData));
  }

  static syncWhenOnline(): Promise<boolean> {
    return new Promise((resolve) => {
      if (navigator.onLine) {
        // Simulate sync with server
        setTimeout(() => {
          console.log('Data synced with server');
          resolve(true);
        }, 2000);
      } else {
        resolve(false);
      }
    });
  }
}