interface TimelineEvent {
  id: string;
  date: Date;
  type: 'symptom' | 'medicine' | 'followup' | 'achievement' | 'improvement';
  title: string;
  description: string;
  severity?: 'mild' | 'moderate' | 'severe';
  improvement?: 'better' | 'same' | 'worse';
}

export class HealthTimelineService {
  static async getTimeline(): Promise<TimelineEvent[]> {
    await new Promise(resolve => setTimeout(resolve, 500));

    return [
      {
        id: '1',
        date: new Date(Date.now() - 3600000), // 1 hour ago
        type: 'followup',
        title: 'Follow-up Complete',
        description: 'Completed follow-up for persistent cough - showing improvement',
        improvement: 'better'
      },
      {
        id: '2',
        date: new Date(Date.now() - 86400000), // 1 day ago
        type: 'medicine',
        title: 'Medicine Scanned',
        description: 'Scanned Ibuprofen 200mg - Added to medication profile',
      },
      {
        id: '3',
        date: new Date(Date.now() - 172800000), // 2 days ago
        type: 'symptom',
        title: 'Symptom Assessment',
        description: 'Reported persistent cough and chest tightness',
        severity: 'moderate'
      },
      {
        id: '4',
        date: new Date(Date.now() - 259200000), // 3 days ago
        type: 'achievement',
        title: 'Health Milestone',
        description: 'Completed 7-day health tracking streak',
      },
      {
        id: '5',
        date: new Date(Date.now() - 432000000), // 5 days ago
        type: 'followup',
        title: 'Follow-up Complete',
        description: 'Headache symptoms resolved after lifestyle changes',
        improvement: 'better'
      }
    ];
  }

  static async addEvent(event: Omit<TimelineEvent, 'id'>): Promise<void> {
    await new Promise(resolve => setTimeout(resolve, 300));
    console.log('Timeline event added:', event);
  }
}