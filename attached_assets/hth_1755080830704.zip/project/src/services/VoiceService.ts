export class VoiceService {
  static async startListening(language: string): Promise<string> {
    // Simulate voice recognition
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    const mockTranscripts = [
      "I've been having a persistent cough for the past three days with some chest tightness.",
      "I'm experiencing headaches that seem to get worse in the afternoon.",
      "My stomach has been upset since yesterday, with some nausea.",
      "I've noticed some joint pain in my knees, especially when walking.",
      "I'm feeling very tired lately and having trouble sleeping."
    ];

    return mockTranscripts[Math.floor(Math.random() * mockTranscripts.length)];
  }

  static async generateResponse(transcript: string, language: string): Promise<string> {
    await new Promise(resolve => setTimeout(resolve, 2000));

    const lowerTranscript = transcript.toLowerCase();
    
    if (lowerTranscript.includes('cough')) {
      return "I understand you're experiencing a persistent cough with chest tightness. This could indicate a respiratory condition. I recommend staying hydrated, using a humidifier, and monitoring your symptoms. If the cough worsens or you develop fever, please seek medical attention.";
    }
    
    if (lowerTranscript.includes('headache')) {
      return "Afternoon headaches can be related to dehydration, eye strain, or stress. Try drinking more water, taking regular breaks if you work at a computer, and practicing relaxation techniques. If headaches become severe or frequent, consult a healthcare provider.";
    }
    
    if (lowerTranscript.includes('stomach') || lowerTranscript.includes('nausea')) {
      return "Stomach upset and nausea can have various causes. Try eating bland foods, staying hydrated with small sips of water, and avoiding dairy or fatty foods temporarily. If symptoms persist beyond 48 hours, please consult a healthcare professional.";
    }

    return "Thank you for sharing your health concerns with me. I've noted your symptoms and will help you track your progress. Based on what you've described, I recommend monitoring your condition and I'll follow up with you in 24-48 hours to check on your improvement.";
  }

  static speak(text: string, language: string): void {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = language === 'en' ? 'en-US' : 
                     language === 'es' ? 'es-ES' : 
                     language === 'fr' ? 'fr-FR' : 
                     language === 'ar' ? 'ar-SA' : 
                     language === 'hi' ? 'hi-IN' : 'en-US';
      speechSynthesis.speak(utterance);
    }
  }
}