interface MedicineResult {
  name: string;
  genericName: string;
  dosage: string;
  frequency: string;
  warnings: string[];
  interactions: string[];
  sideEffects: string[];
}

export class MedicineService {
  static async scanMedicine(imageData: string): Promise<MedicineResult> {
    // Simulate AI image processing delay
    await new Promise(resolve => setTimeout(resolve, 3000));

    // Mock medicine database responses
    const mockMedicines: MedicineResult[] = [
      {
        name: 'Ibuprofen 200mg',
        genericName: 'Ibuprofen',
        dosage: '200mg per tablet',
        frequency: 'Every 4-6 hours as needed (max 1200mg/day)',
        warnings: [
          'Do not exceed recommended dose',
          'Take with food to reduce stomach irritation',
          'Not recommended for children under 6 months'
        ],
        interactions: [
          'Blood thinners (increased bleeding risk)',
          'ACE inhibitors (reduced effectiveness)',
          'Lithium (increased lithium levels)'
        ],
        sideEffects: [
          'Stomach upset or heartburn',
          'Dizziness or drowsiness',
          'Mild skin rash',
          'Headache'
        ]
      },
      {
        name: 'Paracetamol 500mg',
        genericName: 'Acetaminophen',
        dosage: '500mg per tablet',
        frequency: 'Every 4-6 hours (max 4000mg/day)',
        warnings: [
          'Do not exceed 4000mg in 24 hours',
          'Avoid alcohol while taking this medication',
          'Check other medications for acetaminophen content'
        ],
        interactions: [
          'Warfarin (increased bleeding risk)',
          'Phenytoin (reduced effectiveness)',
          'Alcohol (liver damage risk)'
        ],
        sideEffects: [
          'Rare allergic reactions',
          'Liver damage with overdose',
          'Skin rash (uncommon)',
          'Nausea (rare)'
        ]
      }
    ];

    // Return a random medicine for demo purposes
    return mockMedicines[Math.floor(Math.random() * mockMedicines.length)];
  }

  static async getDrugInteractions(medicines: string[]): Promise<string[]> {
    // Mock drug interaction checking
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return [
      'No significant interactions detected',
      'Monitor for increased drowsiness when combining these medications',
      'Consult pharmacist before taking together'
    ];
  }
}