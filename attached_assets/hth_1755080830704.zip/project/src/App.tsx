import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { SymptomChecker } from './components/SymptomChecker';
import { MedicineScanner } from './components/MedicineScanner';
import { VoiceAssistant } from './components/VoiceAssistant';
import { FollowUpSystem } from './components/FollowUpSystem';
import { HealthTimeline } from './components/HealthTimeline';
import { Settings } from './components/Settings';
import { OfflineService } from './services/OfflineService';
import { LanguageProvider } from './contexts/LanguageContext';

export type View = 'dashboard' | 'symptoms' | 'medicine' | 'voice' | 'followup' | 'timeline' | 'settings';

function App() {
  const [currentView, setCurrentView] = useState<View>('dashboard');
  const [isOffline, setIsOffline] = useState(false);

  useEffect(() => {
    // Initialize offline service
    OfflineService.init();

    // Monitor online/offline status
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentView} currentView={currentView} />;
      case 'symptoms':
        return <SymptomChecker onBack={() => setCurrentView('dashboard')} />;
      case 'medicine':
        return <MedicineScanner onBack={() => setCurrentView('dashboard')} />;
      case 'voice':
        return <VoiceAssistant onBack={() => setCurrentView('dashboard')} />;
      case 'followup':
        return <FollowUpSystem onBack={() => setCurrentView('dashboard')} />;
      case 'timeline':
        return <HealthTimeline onBack={() => setCurrentView('dashboard')} />;
      case 'settings':
        return <Settings onBack={() => setCurrentView('dashboard')} />;
      default:
        return <Dashboard onNavigate={setCurrentView} />;
    }
  };

  return (
    <LanguageProvider>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-teal-50">
        <Header 
          currentView={currentView} 
          onNavigate={setCurrentView}
          isOffline={isOffline}
        />
        <main className="pb-20">
          {renderView()}
        </main>
      </div>
    </LanguageProvider>
  );
}

export default App;