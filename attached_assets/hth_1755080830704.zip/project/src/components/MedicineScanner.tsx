import React, { useState, useRef } from 'react';
import { ArrowLeft, Camera, Upload, Pill, Clock, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { MedicineService } from '../services/MedicineService';

interface MedicineScannerProps {
  onBack: () => void;
}

interface MedicineResult {
  name: string;
  genericName: string;
  dosage: string;
  frequency: string;
  warnings: string[];
  interactions: string[];
  sideEffects: string[];
}

export function MedicineScanner({ onBack }: MedicineScannerProps) {
  const { t } = useLanguage();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<MedicineResult | null>(null);

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleScanMedicine = async () => {
    if (!selectedImage) return;

    setIsScanning(true);
    try {
      const result = await MedicineService.scanMedicine(selectedImage);
      setScanResult(result);
    } catch (error) {
      console.error('Medicine scan failed:', error);
    } finally {
      setIsScanning(false);
    }
  };

  const handleTakePhoto = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">{t('medicineScanner')}</h2>
        <p className="text-gray-600 mb-6">{t('scanMedicineDescription')}</p>

        {/* Image Upload Area */}
        <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center mb-6">
          {selectedImage ? (
            <div className="space-y-4">
              <img 
                src={selectedImage} 
                alt="Selected medicine" 
                className="max-w-full max-h-64 mx-auto rounded-lg shadow-md"
              />
              <div className="flex justify-center space-x-4">
                <button
                  onClick={handleTakePhoto}
                  className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
                >
                  <Camera className="w-5 h-5" />
                  <span>{t('retakePhoto')}</span>
                </button>
                <button
                  onClick={handleScanMedicine}
                  disabled={isScanning}
                  className="flex items-center space-x-2 px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 transition-colors"
                >
                  <Pill className="w-5 h-5" />
                  <span>{isScanning ? t('scanning') : t('scanMedicine')}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <Camera className="w-16 h-16 text-gray-400 mx-auto" />
              <div>
                <p className="text-lg font-medium text-gray-900 mb-2">{t('uploadMedicinePhoto')}</p>
                <p className="text-gray-600 mb-4">{t('photoInstructions')}</p>
                <div className="flex justify-center space-x-4">
                  <button
                    onClick={handleTakePhoto}
                    className="flex items-center space-x-2 px-6 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    <Camera className="w-5 h-5" />
                    <span>{t('takePhoto')}</span>
                  </button>
                  <button
                    onClick={handleTakePhoto}
                    className="flex items-center space-x-2 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Upload className="w-5 h-5" />
                    <span>{t('uploadPhoto')}</span>
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageUpload}
          className="hidden"
        />

        {/* Scanning Progress */}
        {isScanning && (
          <div className="bg-blue-50 rounded-xl p-6 mb-6">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
              <span className="font-medium text-blue-900">{t('analyzingMedicine')}</span>
            </div>
            <div className="w-full bg-blue-200 rounded-full h-2">
              <div className="bg-blue-500 h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
            </div>
          </div>
        )}

        {/* Scan Results */}
        {scanResult && (
          <div className="space-y-6">
            <div className="flex items-center space-x-3 text-green-600">
              <CheckCircle className="w-6 h-6" />
              <span className="font-semibold">{t('medicineIdentified')}</span>
            </div>

            {/* Medicine Information */}
            <div className="bg-gradient-to-r from-blue-50 to-teal-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-2">{scanResult.name}</h3>
              <p className="text-gray-600 mb-4">{t('genericName')}: {scanResult.genericName}</p>
              
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">{t('dosageInformation')}</h4>
                  <div className="space-y-2">
                    <div className="flex items-center space-x-2">
                      <Pill className="w-4 h-4 text-blue-500" />
                      <span className="text-sm">{t('dosage')}: {scanResult.dosage}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-green-500" />
                      <span className="text-sm">{t('frequency')}: {scanResult.frequency}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">{t('warnings')}</h4>
                  <div className="space-y-1">
                    {scanResult.warnings.map((warning, index) => (
                      <div key={index} className="flex items-start space-x-2">
                        <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                        <span className="text-sm text-gray-700">{warning}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Detailed Information */}
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h4 className="font-semibold text-gray-900 mb-3">{t('drugInteractions')}</h4>
                <div className="space-y-2">
                  {scanResult.interactions.map((interaction, index) => (
                    <p key={index} className="text-sm text-gray-700">• {interaction}</p>
                  ))}
                </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-xl p-6">
                <h4 className="font-semibold text-gray-900 mb-3">{t('sideEffects')}</h4>
                <div className="space-y-2">
                  {scanResult.sideEffects.map((effect, index) => (
                    <p key={index} className="text-sm text-gray-700">• {effect}</p>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-center space-x-4">
              <button className="px-6 py-3 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
                {t('saveToProfile')}
              </button>
              <button className="px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
                {t('shareWithDoctor')}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}