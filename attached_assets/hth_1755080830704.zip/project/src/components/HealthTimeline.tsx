import React, { useState, useEffect } from 'react';
import { ArrowLeft, Calendar, TrendingUp, Award, Activity } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { HealthTimelineService } from '../services/HealthTimelineService';

interface HealthTimelineProps {
  onBack: () => void;
}

interface TimelineEvent {
  id: string;
  date: Date;
  type: 'symptom' | 'medicine' | 'followup' | 'achievement' | 'improvement';
  title: string;
  description: string;
  severity?: 'mild' | 'moderate' | 'severe';
  improvement?: 'better' | 'same' | 'worse';
}

export function HealthTimeline({ onBack }: HealthTimelineProps) {
  const { t } = useLanguage();
  const [timeline, setTimeline] = useState<TimelineEvent[]>([]);
  const [healthScore, setHealthScore] = useState(85);
  const [weeklyTrend, setWeeklyTrend] = useState('+5%');

  useEffect(() => {
    loadTimeline();
  }, []);

  const loadTimeline = async () => {
    const data = await HealthTimelineService.getTimeline();
    setTimeline(data);
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'symptom': return Activity;
      case 'medicine': return Calendar;
      case 'followup': return TrendingUp;
      case 'achievement': return Award;
      default: return Activity;
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case 'symptom': return 'blue';
      case 'medicine': return 'teal';
      case 'followup': return 'green';
      case 'achievement': return 'purple';
      default: return 'gray';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      {/* Health Score Overview */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
        <div className="text-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('healthTimeline')}</h2>
          <p className="text-gray-600">{t('trackYourProgress')}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="relative w-24 h-24 mx-auto mb-4">
              <svg className="w-24 h-24 transform -rotate-90">
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  className="text-gray-200"
                />
                <circle
                  cx="48"
                  cy="48"
                  r="40"
                  stroke="currentColor"
                  strokeWidth="8"
                  fill="none"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  strokeDashoffset={`${2 * Math.PI * 40 * (1 - healthScore / 100)}`}
                  className="text-green-500"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-2xl font-bold text-gray-900">{healthScore}</span>
              </div>
            </div>
            <p className="font-semibold text-gray-900">{t('healthScore')}</p>
          </div>

          <div className="text-center">
            <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-teal-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-10 h-10 text-white" />
            </div>
            <p className="text-2xl font-bold text-green-600">{weeklyTrend}</p>
            <p className="font-medium text-gray-600">{t('weeklyImprovement')}</p>
          </div>

          <div className="text-center">
            <div className="w-24 h-24 mx-auto mb-4 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
              <Award className="w-10 h-10 text-white" />
            </div>
            <p className="text-2xl font-bold text-purple-600">12</p>
            <p className="font-medium text-gray-600">{t('achievements')}</p>
          </div>
        </div>
      </div>

      {/* Timeline */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">{t('recentActivity')}</h3>
        
        <div className="relative">
          <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          
          <div className="space-y-6">
            {timeline.map((event, index) => {
              const Icon = getEventIcon(event.type);
              const color = getEventColor(event.type);
              
              return (
                <div key={event.id} className="relative flex items-start space-x-4">
                  <div className={`w-8 h-8 bg-${color}-500 rounded-full flex items-center justify-center z-10`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="bg-gray-50 rounded-xl p-4">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-gray-900">{event.title}</h4>
                        <span className="text-sm text-gray-500">
                          {event.date.toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-gray-700 mb-2">{event.description}</p>
                      
                      {event.improvement && (
                        <div className="flex items-center space-x-2">
                          {getImprovementIcon(event.improvement)}
                          <span className="text-sm font-medium text-gray-900">
                            {t('status')}: {t(event.improvement)}
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Pending Follow-ups */}
      {followUps.filter(f => f.status === 'pending').length > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 mt-6">
          <h3 className="font-semibold text-yellow-800 mb-4">{t('pendingFollowUps')}</h3>
          <div className="space-y-3">
            {followUps.filter(f => f.status === 'pending').map((followUp) => (
              <div key={followUp.id} className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-yellow-900">{followUp.symptom}</p>
                  <p className="text-sm text-yellow-700">
                    {t('due')}: {followUp.scheduledDate.toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={() => setSelectedFollowUp(followUp)}
                  className="px-4 py-2 bg-yellow-500 text-white rounded-lg hover:bg-yellow-600 transition-colors"
                >
                  {t('complete')}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}