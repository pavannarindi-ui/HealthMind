import React from 'react';
import { 
  Stethoscope, 
  Camera, 
  Mic, 
  Calendar, 
  Activity, 
  Award,
  Users,
  TrendingUp
} from 'lucide-react';
import { View } from '../App';
import { useLanguage } from '../contexts/LanguageContext';

interface DashboardProps {
  onNavigate: (view: View) => void;
  currentView: View;
}

export function Dashboard({ onNavigate, currentView }: DashboardProps) {
  const { t } = useLanguage();

  const quickActions = [
    {
      id: 'symptoms',
      icon: Stethoscope,
      title: t('symptomChecker'),
      description: t('describeSymptoms'),
      color: 'from-blue-500 to-blue-600',
      view: 'symptoms' as View
    },
    {
      id: 'medicine',
      icon: Camera,
      title: t('medicineScanner'),
      description: t('scanMedicine'),
      color: 'from-teal-500 to-teal-600',
      view: 'medicine' as View
    },
    {
      id: 'voice',
      icon: Mic,
      title: t('voiceAssistant'),
      description: t('speakToAI'),
      color: 'from-purple-500 to-purple-600',
      view: 'voice' as View
    },
    {
      id: 'followup',
      icon: Calendar,
      title: t('followUp'),
      description: t('checkProgress'),
      color: 'from-green-500 to-green-600',
      view: 'followup' as View
    }
  ];

  const stats = [
    { label: t('consultations'), value: '24', icon: Activity },
    { label: t('healthScore'), value: '85%', icon: TrendingUp },
    { label: t('achievements'), value: '12', icon: Award },
    { label: t('community'), value: '1.2k', icon: Users }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Welcome Section */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">{t('welcomeBack')}</h2>
        <p className="text-gray-600">{t('howFeeling')}</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                <p className="text-sm text-gray-600">{stat.label}</p>
              </div>
              <stat.icon className="w-8 h-8 text-blue-500" />
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">{t('quickActions')}</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {quickActions.map((action) => (
            <button
              key={action.id}
              onClick={() => onNavigate(action.view)}
              className="group bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-lg hover:scale-105 transition-all duration-300"
            >
              <div className="flex items-start space-x-4">
                <div className={`w-12 h-12 bg-gradient-to-r ${action.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <action.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1 text-left">
                  <h4 className="font-semibold text-gray-900 mb-1">{action.title}</h4>
                  <p className="text-sm text-gray-600">{action.description}</p>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">{t('recentActivity')}</h3>
        <div className="space-y-4">
          <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            <span className="text-sm text-gray-700">{t('followUpCompleted')}</span>
            <span className="text-xs text-gray-500 ml-auto">2h ago</span>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
            <span className="text-sm text-gray-700">{t('medicineScanned')}</span>
            <span className="text-xs text-gray-500 ml-auto">1d ago</span>
          </div>
          <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
            <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
            <span className="text-sm text-gray-700">{t('symptomCheckCompleted')}</span>
            <span className="text-xs text-gray-500 ml-auto">2d ago</span>
          </div>
        </div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-2">
        <div className="max-w-md mx-auto">
          <div className="flex justify-around">
            {[
              { view: 'dashboard' as View, icon: Activity, label: t('home') },
              { view: 'timeline' as View, icon: Calendar, label: t('timeline') },
              { view: 'voice' as View, icon: Mic, label: t('voice') },
              { view: 'settings' as View, icon: Award, label: t('profile') }
            ].map((item) => (
              <button
                key={item.view}
                onClick={() => onNavigate(item.view)}
                className={`flex flex-col items-center space-y-1 py-2 px-3 rounded-lg transition-all ${
                  currentView === item.view 
                    ? 'text-blue-600 bg-blue-50' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <item.icon className="w-5 h-5" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}