import React, { useState, useEffect } from 'react';
import { ArrowLeft, Calendar, Clock, CheckCircle, AlertCircle, TrendingUp, TrendingDown } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { FollowUpService } from '../services/FollowUpService';

interface FollowUpSystemProps {
  onBack: () => void;
}

interface FollowUp {
  id: string;
  symptom: string;
  severity: 'mild' | 'moderate' | 'severe';
  scheduledDate: Date;
  status: 'pending' | 'completed' | 'missed';
  improvement: 'better' | 'same' | 'worse' | null;
  notes: string;
}

export function FollowUpSystem({ onBack }: FollowUpSystemProps) {
  const { t } = useLanguage();
  const [followUps, setFollowUps] = useState<FollowUp[]>([]);
  const [selectedFollowUp, setSelectedFollowUp] = useState<FollowUp | null>(null);
  const [improvement, setImprovement] = useState<'better' | 'same' | 'worse' | null>(null);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    loadFollowUps();
  }, []);

  const loadFollowUps = async () => {
    const data = await FollowUpService.getFollowUps();
    setFollowUps(data);
  };

  const handleCompleteFollowUp = async () => {
    if (!selectedFollowUp || !improvement) return;

    await FollowUpService.completeFollowUp(selectedFollowUp.id, improvement, notes);
    setSelectedFollowUp(null);
    setImprovement(null);
    setNotes('');
    loadFollowUps();
  };

  const getImprovementIcon = (improvement: string | null) => {
    switch (improvement) {
      case 'better': return <TrendingUp className="w-5 h-5 text-green-500" />;
      case 'worse': return <TrendingDown className="w-5 h-5 text-red-500" />;
      case 'same': return <div className="w-5 h-5 border-2 border-yellow-500 rounded-full" />;
      default: return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'mild': return 'bg-green-100 text-green-800';
      case 'moderate': return 'bg-yellow-100 text-yellow-800';
      case 'severe': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      {selectedFollowUp ? (
        /* Follow-up Detail View */
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('followUpCheck')}</h2>
          
          <div className="bg-blue-50 rounded-xl p-6 mb-6">
            <h3 className="font-semibold text-gray-900 mb-2">{t('originalSymptom')}</h3>
            <p className="text-gray-700 mb-4">{selectedFollowUp.symptom}</p>
            <div className="flex items-center space-x-4">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSeverityColor(selectedFollowUp.severity)}`}>
                {t(selectedFollowUp.severity)}
              </span>
              <span className="text-sm text-gray-600">
                {t('scheduled')}: {selectedFollowUp.scheduledDate.toLocaleDateString()}
              </span>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-4">{t('howFeelingNow')}</h3>
              <div className="grid grid-cols-3 gap-4">
                {[
                  { value: 'better', label: t('better'), color: 'green', icon: TrendingUp },
                  { value: 'same', label: t('same'), color: 'yellow', icon: Clock },
                  { value: 'worse', label: t('worse'), color: 'red', icon: TrendingDown }
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setImprovement(option.value as any)}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      improvement === option.value
                        ? `border-${option.color}-500 bg-${option.color}-50`
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    <option.icon className={`w-8 h-8 mx-auto mb-2 ${
                      improvement === option.value ? `text-${option.color}-500` : 'text-gray-400'
                    }`} />
                    <p className="font-medium text-gray-900">{option.label}</p>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block font-semibold text-gray-900 mb-2">{t('additionalNotes')}</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder={t('shareAnyChanges')}
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <div className="flex justify-center">
              <button
                onClick={handleCompleteFollowUp}
                disabled={!improvement}
                className="px-8 py-3 bg-blue-500 text-white rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {t('submitFollowUp')}
              </button>
            </div>
          </div>
        </div>
      ) : (
        /* Follow-up List View */
        <div>
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">{t('followUpSystem')}</h2>
            <p className="text-gray-600 mb-6">{t('followUpDescription')}</p>

            {/* Follow-up Statistics */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
              {[
                { label: t('pending'), value: '3', color: 'blue' },
                { label: t('completed'), value: '12', color: 'green' },
                { label: t('improved'), value: '85%', color: 'teal' },
                { label: t('needAttention'), value: '1', color: 'red' }
              ].map((stat, index) => (
                <div key={index} className="bg-gray-50 rounded-xl p-4 text-center">
                  <p className={`text-2xl font-bold text-${stat.color}-600`}>{stat.value}</p>
                  <p className="text-sm text-gray-600">{stat.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Follow-up List */}
          <div className="space-y-4">
            {followUps.map((followUp) => (
              <div
                key={followUp.id}
                className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      {getImprovementIcon(followUp.improvement)}
                      <h3 className="font-semibold text-gray-900">{followUp.symptom}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(followUp.severity)}`}>
                        {t(followUp.severity)}
                      </span>
                    </div>
                    <div className="flex items-center space-x-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Calendar className="w-4 h-4" />
                        <span>{followUp.scheduledDate.toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        {followUp.status === 'completed' ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-yellow-500" />
                        )}
                        <span>{t(followUp.status)}</span>
                      </div>
                    </div>
                  </div>
                  
                  {followUp.status === 'pending' && (
                    <button
                      onClick={() => setSelectedFollowUp(followUp)}
                      className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                    >
                      {t('checkIn')}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}