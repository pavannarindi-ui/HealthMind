import React, { useState } from 'react';
import { ArrowLeft, Send, AlertCircle, CheckCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { AIService } from '../services/AIService';

interface SymptomCheckerProps {
  onBack: () => void;
}

export function SymptomChecker({ onBack }: SymptomCheckerProps) {
  const { t } = useLanguage();
  const [symptoms, setSymptoms] = useState('');
  const [chatHistory, setChatHistory] = useState<Array<{
    type: 'user' | 'ai';
    message: string;
    timestamp: Date;
  }>>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  const handleSubmitSymptoms = async () => {
    if (!symptoms.trim()) return;

    const userMessage = { type: 'user' as const, message: symptoms, timestamp: new Date() };
    setChatHistory(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await AIService.analyzeSymptoms(symptoms);
      const aiMessage = { type: 'ai' as const, message: response, timestamp: new Date() };
      setChatHistory(prev => [...prev, aiMessage]);
      setCurrentStep(prev => prev + 1);
    } catch (error) {
      const errorMessage = { type: 'ai' as const, message: t('analysisError'), timestamp: new Date() };
      setChatHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
      setSymptoms('');
    }
  };

  const emergencySymptoms = [
    t('chestPain'),
    t('breathingDifficulty'),
    t('severeHeadache'),
    t('suddenWeakness')
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      {/* Emergency Warning */}
      <div className="bg-red-50 border border-red-200 rounded-xl p-4 mb-6">
        <div className="flex items-start space-x-3">
          <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-semibold text-red-800 mb-2">{t('emergencyWarning')}</h3>
            <p className="text-sm text-red-700 mb-3">{t('emergencyDescription')}</p>
            <div className="flex flex-wrap gap-2">
              {emergencySymptoms.map((symptom, index) => (
                <span key={index} className="bg-red-100 text-red-800 text-xs px-2 py-1 rounded-full">
                  {symptom}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 mb-6">
        <div className="p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">{t('symptomConversation')}</h2>
          
          {chatHistory.length === 0 && (
            <div className="text-center py-8">
              <Stethoscope className="w-16 h-16 text-blue-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">{t('describeSymptoms')}</p>
            </div>
          )}

          <div className="space-y-4 max-h-96 overflow-y-auto mb-4">
            {chatHistory.map((entry, index) => (
              <div
                key={index}
                className={`flex ${entry.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                    entry.type === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm">{entry.message}</p>
                  <p className={`text-xs mt-1 ${
                    entry.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {entry.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 rounded-2xl px-4 py-3">
                  <div className="flex space-x-2">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex space-x-2">
            <input
              type="text"
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              placeholder={t('typeSymptoms')}
              className="flex-1 px-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              onKeyPress={(e) => e.key === 'Enter' && handleSubmitSymptoms()}
            />
            <button
              onClick={handleSubmitSymptoms}
              disabled={!symptoms.trim() || isLoading}
              className="px-6 py-3 bg-blue-500 text-white rounded-xl hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Progress Indicator */}
      {chatHistory.length > 0 && (
        <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
          <h3 className="font-semibold text-gray-900 mb-4">{t('assessmentProgress')}</h3>
          <div className="flex items-center space-x-4">
            <div className="flex-1 bg-gray-200 rounded-full h-2">
              <div 
                className="bg-gradient-to-r from-blue-500 to-teal-500 h-2 rounded-full transition-all duration-500"
                style={{ width: `${Math.min((currentStep / 3) * 100, 100)}%` }}
              ></div>
            </div>
            <span className="text-sm font-medium text-gray-700">
              {Math.min(Math.round((currentStep / 3) * 100), 100)}%
            </span>
          </div>
        </div>
      )}
    </div>
  );
}