import React, { useState, useEffect } from 'react';
import { ArrowLeft, Mic, MicOff, Volume2, Languages } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { VoiceService } from '../services/VoiceService';

interface VoiceAssistantProps {
  onBack: () => void;
}

export function VoiceAssistant({ onBack }: VoiceAssistantProps) {
  const { t, language } = useLanguage();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [audioLevel, setAudioLevel] = useState(0);
  const [conversationHistory, setConversationHistory] = useState<Array<{
    type: 'user' | 'ai';
    text: string;
    timestamp: Date;
  }>>([]);

  useEffect(() => {
    // Simulate audio level animation when listening
    let interval: NodeJS.Timeout;
    if (isListening) {
      interval = setInterval(() => {
        setAudioLevel(Math.random() * 100);
      }, 100);
    } else {
      setAudioLevel(0);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isListening]);

  const startListening = async () => {
    setIsListening(true);
    setTranscript('');
    
    try {
      const result = await VoiceService.startListening(language);
      setTranscript(result);
    } catch (error) {
      console.error('Voice recognition failed:', error);
    }
  };

  const stopListening = async () => {
    setIsListening(false);
    
    if (transcript) {
      const userEntry = { type: 'user' as const, text: transcript, timestamp: new Date() };
      setConversationHistory(prev => [...prev, userEntry]);

      // Simulate AI response
      setTimeout(async () => {
        const response = await VoiceService.generateResponse(transcript, language);
        setAiResponse(response);
        const aiEntry = { type: 'ai' as const, text: response, timestamp: new Date() };
        setConversationHistory(prev => [...prev, aiEntry]);
        
        // Speak the response
        VoiceService.speak(response, language);
      }, 1000);
    }
  };

  const speakResponse = () => {
    if (aiResponse) {
      VoiceService.speak(aiResponse, language);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">{t('voiceAssistant')}</h2>
          <p className="text-gray-600">{t('voiceAssistantDescription')}</p>
        </div>

        {/* Voice Visualizer */}
        <div className="flex justify-center mb-8">
          <div className="relative">
            <button
              onClick={isListening ? stopListening : startListening}
              className={`w-24 h-24 rounded-full flex items-center justify-center transition-all duration-300 ${
                isListening 
                  ? 'bg-red-500 hover:bg-red-600 animate-pulse' 
                  : 'bg-blue-500 hover:bg-blue-600'
              }`}
            >
              {isListening ? (
                <MicOff className="w-10 h-10 text-white" />
              ) : (
                <Mic className="w-10 h-10 text-white" />
              )}
            </button>
            
            {/* Audio Level Visualization */}
            {isListening && (
              <div className="absolute inset-0 rounded-full border-4 border-red-300 animate-ping"></div>
            )}
          </div>
        </div>

        {/* Audio Level Bars */}
        {isListening && (
          <div className="flex justify-center space-x-1 mb-6">
            {[...Array(20)].map((_, i) => (
              <div
                key={i}
                className="w-1 bg-blue-500 rounded-full transition-all duration-75"
                style={{
                  height: `${Math.random() * 40 + 10}px`,
                  opacity: Math.random() * 0.7 + 0.3
                }}
              ></div>
            ))}
          </div>
        )}

        {/* Current Transcript */}
        {transcript && (
          <div className="bg-blue-50 rounded-xl p-4 mb-6">
            <h3 className="font-semibold text-blue-900 mb-2">{t('youSaid')}</h3>
            <p className="text-blue-800">{transcript}</p>
          </div>
        )}

        {/* Language Selection */}
        <div className="flex items-center justify-center space-x-4 mb-6">
          <Languages className="w-5 h-5 text-gray-500" />
          <span className="text-sm text-gray-600">{t('speakingIn')}: </span>
          <span className="font-medium text-gray-900">
            {language === 'en' && 'English'}
            {language === 'es' && 'Español'}
            {language === 'fr' && 'Français'}
            {language === 'ar' && 'العربية'}
            {language === 'hi' && 'हिंदी'}
          </span>
        </div>

        {/* Instructions */}
        <div className="bg-gray-50 rounded-xl p-4">
          <h3 className="font-semibold text-gray-900 mb-2">{t('howToUse')}</h3>
          <ul className="space-y-1 text-sm text-gray-700">
            <li>• {t('tapMicToStart')}</li>
            <li>• {t('speakClearly')}</li>
            <li>• {t('tapAgainToStop')}</li>
            <li>• {t('aiWillRespond')}</li>
          </ul>
        </div>
      </div>

      {/* Conversation History */}
      {conversationHistory.length > 0 && (
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-xl font-semibold text-gray-900 mb-4">{t('conversation')}</h3>
          <div className="space-y-4 max-h-96 overflow-y-auto">
            {conversationHistory.map((entry, index) => (
              <div
                key={index}
                className={`flex ${entry.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                    entry.type === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm">{entry.text}</p>
                  {entry.type === 'ai' && (
                    <button
                      onClick={speakResponse}
                      className="flex items-center space-x-1 mt-2 text-gray-600 hover:text-gray-800 transition-colors"
                    >
                      <Volume2 className="w-4 h-4" />
                      <span className="text-xs">{t('playAudio')}</span>
                    </button>
                  )}
                  <p className={`text-xs mt-1 ${
                    entry.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                  }`}>
                    {entry.timestamp.toLocaleTimeString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}