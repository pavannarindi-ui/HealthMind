import React from 'react';
import { Menu, Wifi, WifiOff, Globe } from 'lucide-react';
import { View } from '../App';
import { useLanguage } from '../contexts/LanguageContext';

interface HeaderProps {
  currentView: View;
  onNavigate: (view: View) => void;
  isOffline: boolean;
}

export function Header({ currentView, onNavigate, isOffline }: HeaderProps) {
  const { language, setLanguage, t } = useLanguage();

  const getTitle = () => {
    switch (currentView) {
      case 'dashboard': return t('dashboard');
      case 'symptoms': return t('symptomChecker');
      case 'medicine': return t('medicineScanner');
      case 'voice': return t('voiceAssistant');
      case 'followup': return t('followUp');
      case 'timeline': return t('healthTimeline');
      case 'settings': return t('settings');
      default: return t('healthPlatform');
    }
  };

  return (
    <header className="bg-white shadow-lg border-b border-blue-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-teal-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">H+</span>
              </div>
              <h1 className="text-xl font-bold text-gray-900">{getTitle()}</h1>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              {isOffline ? (
                <WifiOff className="w-5 h-5 text-red-500" />
              ) : (
                <Wifi className="w-5 h-5 text-green-500" />
              )}
              <span className="text-sm text-gray-600">
                {isOffline ? t('offline') : t('online')}
              </span>
            </div>

            <div className="flex items-center space-x-2">
              <Globe className="w-4 h-4 text-gray-500" />
              <select
                value={language}
                onChange={(e) => setLanguage(e.target.value)}
                className="text-sm bg-transparent border-none focus:outline-none text-gray-700"
              >
                <option value="en">English</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
                <option value="ar">العربية</option>
                <option value="hi">हिंदी</option>
              </select>
            </div>

            <button
              onClick={() => onNavigate('settings')}
              className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}