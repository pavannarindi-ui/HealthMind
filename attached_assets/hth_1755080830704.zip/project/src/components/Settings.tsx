import React from 'react';
import { ArrowLeft, User, Bell, Shield, Globe, Download, Smartphone } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface SettingsProps {
  onBack: () => void;
}

export function Settings({ onBack }: SettingsProps) {
  const { t, language, setLanguage } = useLanguage();

  const settingsSections = [
    {
      title: t('profile'),
      icon: User,
      items: [
        { label: t('personalInfo'), action: () => {} },
        { label: t('medicalHistory'), action: () => {} },
        { label: t('emergencyContacts'), action: () => {} }
      ]
    },
    {
      title: t('preferences'),
      icon: Bell,
      items: [
        { label: t('notifications'), action: () => {} },
        { label: t('followUpReminders'), action: () => {} },
        { label: t('healthGoals'), action: () => {} }
      ]
    },
    {
      title: t('privacy'),
      icon: Shield,
      items: [
        { label: t('dataSharing'), action: () => {} },
        { label: t('anonymousMode'), action: () => {} },
        { label: t('exportData'), action: () => {} }
      ]
    },
    {
      title: t('accessibility'),
      icon: Smartphone,
      items: [
        { label: t('voiceSettings'), action: () => {} },
        { label: t('textSize'), action: () => {} },
        { label: t('colorContrast'), action: () => {} }
      ]
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>{t('back')}</span>
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-6 mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('settings')}</h2>

        {/* Language Settings */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Globe className="w-6 h-6 text-blue-500" />
            <h3 className="text-lg font-semibold text-gray-900">{t('language')}</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {[
              { code: 'en', name: 'English', flag: '🇺🇸' },
              { code: 'es', name: 'Español', flag: '🇪🇸' },
              { code: 'fr', name: 'Français', flag: '🇫🇷' },
              { code: 'ar', name: 'العربية', flag: '🇸🇦' },
              { code: 'hi', name: 'हिंदी', flag: '🇮🇳' }
            ].map((lang) => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`p-3 rounded-xl border-2 transition-all ${
                  language === lang.code
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="text-2xl mb-1">{lang.flag}</div>
                <p className="font-medium text-gray-900">{lang.name}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Settings Sections */}
        <div className="space-y-6">
          {settingsSections.map((section, sectionIndex) => (
            <div key={sectionIndex}>
              <div className="flex items-center space-x-3 mb-4">
                <section.icon className="w-6 h-6 text-blue-500" />
                <h3 className="text-lg font-semibold text-gray-900">{section.title}</h3>
              </div>
              <div className="space-y-2">
                {section.items.map((item, itemIndex) => (
                  <button
                    key={itemIndex}
                    onClick={item.action}
                    className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors"
                  >
                    <span className="font-medium text-gray-900">{item.label}</span>
                    <ArrowLeft className="w-5 h-5 text-gray-400 transform rotate-180" />
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Offline Data */}
        <div className="mt-8 p-4 bg-green-50 border border-green-200 rounded-xl">
          <div className="flex items-center space-x-3 mb-3">
            <Download className="w-6 h-6 text-green-500" />
            <h3 className="font-semibold text-green-800">{t('offlineMode')}</h3>
          </div>
          <p className="text-sm text-green-700 mb-3">{t('offlineDescription')}</p>
          <button className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
            {t('downloadOfflineData')}
          </button>
        </div>
      </div>
    </div>
  );
}